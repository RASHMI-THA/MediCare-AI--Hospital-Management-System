import { useState, useEffect, useRef, useCallback } from "react";

// ─── SEED DATA ───────────────────────────────────────────────────────────────
const USERS = [
  { email:"admin@medcare.com",  pass:"Admin123",  role:"Admin",   name:"Admin User",       dept:"All" },
  { email:"doctor@medcare.com", pass:"Doctor456", role:"Doctor",  name:"Dr. Rajesh Mehta", dept:"Cardiology" },
  { email:"staff@medcare.com",  pass:"Staff789",  role:"Staff",   name:"Meena Pillai",     dept:"ICU" },
];
const ROLE_CREDS = {
  Admin:  { email:"admin@medcare.com",  pass:"Admin123"  },
  Doctor: { email:"doctor@medcare.com", pass:"Doctor456" },
  Staff:  { email:"staff@medcare.com",  pass:"Staff789"  },
  Patient: null,
};
const INIT_PATIENTS = [
  { id:"P-1001", fname:"Ravi",   lname:"Kumar", age:45, gender:"Male",   dept:"Cardiology",   doctor:"Dr. Rajesh Mehta", admitted:"01 Apr 2026", status:"Admitted",   blood:"B+",  phone:"9876543001" },
  { id:"P-1002", fname:"Priya",  lname:"Singh", age:32, gender:"Female", dept:"Gynaecology",  doctor:"Dr. Anita Shah",   admitted:"28 Mar 2026", status:"Discharged", blood:"A+",  phone:"9876543002" },
  { id:"P-1003", fname:"Arjun",  lname:"Rao",   age:58, gender:"Male",   dept:"Orthopaedics", doctor:"Dr. Vikram Sharma",admitted:"03 Apr 2026", status:"OPD",        blood:"O+",  phone:"9876543003" },
  { id:"P-1004", fname:"Sunita", lname:"Nair",  age:27, gender:"Female", dept:"Neurology",    doctor:"Dr. Kavita Nair",  admitted:"05 Apr 2026", status:"Critical",   blood:"AB-", phone:"9876543004" },
  { id:"P-1005", fname:"Mohan",  lname:"Das",   age:63, gender:"Male",   dept:"Urology",      doctor:"Dr. Rajesh Mehta", admitted:"04 Apr 2026", status:"Admitted",   blood:"B-",  phone:"9876543005" },
  { id:"P-1006", fname:"Ananya", lname:"Iyer",  age:19, gender:"Female", dept:"Paediatrics",  doctor:"Dr. Sunil Patel",  admitted:"30 Mar 2026", status:"Discharged", blood:"O+",  phone:"9876543006" },
  { id:"P-1007", fname:"Suresh", lname:"Menon", age:52, gender:"Male",   dept:"Gastrology",   doctor:"Dr. Ramesh Gupta", admitted:"02 Apr 2026", status:"Admitted",   blood:"A-",  phone:"9876543007" },
];
const INIT_DOCTORS = [
  { id:"D-001", name:"Dr. Rajesh Mehta",  spec:"Cardiology",   qual:"MD, DM Cardio", exp:"18 yrs", today:12, phone:"9800001111", status:"On Duty"  },
  { id:"D-002", name:"Dr. Anita Shah",    spec:"Gynaecology",  qual:"MS OBG",        exp:"14 yrs", today:8,  phone:"9800002222", status:"On Duty"  },
  { id:"D-003", name:"Dr. Vikram Sharma", spec:"Orthopaedics", qual:"MS Ortho",      exp:"20 yrs", today:6,  phone:"9800003333", status:"On Leave" },
  { id:"D-004", name:"Dr. Kavita Nair",   spec:"Neurology",    qual:"DM Neuro",      exp:"10 yrs", today:9,  phone:"9800004444", status:"On Duty"  },
  { id:"D-005", name:"Dr. Sunil Patel",   spec:"Paediatrics",  qual:"MD Paeds",      exp:"12 yrs", today:15, phone:"9800005555", status:"On Duty"  },
  { id:"D-006", name:"Dr. Ramesh Gupta",  spec:"Gastrology",   qual:"DM Gastro",     exp:"16 yrs", today:7,  phone:"9800006666", status:"On Duty"  },
];
const INIT_APPTS = [
  { token:"#T101", pid:"P-1001", patient:"Ravi Kumar",   doctor:"Dr. Rajesh Mehta", dept:"Cardiology",   date:"05 Apr", time:"09:00", type:"OPD",       status:"Confirmed"   },
  { token:"#T102", pid:"P-1002", patient:"Priya Singh",  doctor:"Dr. Anita Shah",   dept:"Gynae",        date:"05 Apr", time:"10:30", type:"Follow-up", status:"In Progress" },
  { token:"#T103", pid:"P-1004", patient:"Sunita Nair",  doctor:"Dr. Kavita Nair",  dept:"Neurology",    date:"05 Apr", time:"11:00", type:"OPD",       status:"Pending"     },
  { token:"#T104", pid:"P-1003", patient:"Arjun Rao",    doctor:"Dr. Vikram Sharma",dept:"Ortho",        date:"06 Apr", time:"09:30", type:"Emergency", status:"Pending"     },
  { token:"#T105", pid:"P-1005", patient:"Mohan Das",    doctor:"Dr. Rajesh Mehta", dept:"Urology",      date:"06 Apr", time:"14:00", type:"OPD",       status:"Confirmed"   },
];
const INIT_RECORDS = [
  { id:"R-2001", patient:"Ravi Kumar",  age:45, diagnosis:"Hypertension, Arrhythmia", doctor:"Dr. Rajesh Mehta", prescription:"Amlodipine, Metoprolol", date:"01 Apr 2026" },
  { id:"R-2002", patient:"Priya Singh", age:32, diagnosis:"Gestational Diabetes",     doctor:"Dr. Anita Shah",   prescription:"Insulin, Metformin",     date:"03 Apr 2026" },
  { id:"R-2003", patient:"Sunita Nair", age:27, diagnosis:"Migraine, Vertigo",        doctor:"Dr. Kavita Nair",  prescription:"Sumatriptan",            date:"04 Apr 2026" },
  { id:"R-2004", patient:"Mohan Das",   age:63, diagnosis:"Kidney Stones",            doctor:"Dr. Rajesh Mehta", prescription:"Tamsulosin, Analgesics", date:"05 Apr 2026" },
];
const INIT_LAB = [
  { id:"L-501", patient:"Ravi Kumar",  test:"ECG + Lipid Panel", orderedBy:"Dr. Rajesh Mehta", date:"04 Apr", status:"Ready"      },
  { id:"L-502", patient:"Sunita Nair", test:"MRI Brain",         orderedBy:"Dr. Kavita Nair",  date:"05 Apr", status:"Processing" },
  { id:"L-503", patient:"Arjun Rao",   test:"X-Ray Knee",        orderedBy:"Dr. Vikram Sharma",date:"05 Apr", status:"Ready"      },
  { id:"L-504", patient:"Mohan Das",   test:"Urine Culture",     orderedBy:"Dr. Rajesh Mehta", date:"05 Apr", status:"Pending"    },
  { id:"L-505", patient:"Priya Singh", test:"HbA1c, FBS",        orderedBy:"Dr. Anita Shah",   date:"05 Apr", status:"Ready"      },
];
const INIT_PHARMA = [
  { name:"Paracetamol 500mg", cat:"Analgesic",      mfg:"Cipla",       stock:120,  reorder:200, expiry:"Dec 2026", price:2.50  },
  { name:"Amoxicillin 250mg", cat:"Antibiotic",     mfg:"Sun Pharma",  stock:850,  reorder:200, expiry:"Mar 2027", price:8.00  },
  { name:"Metformin 500mg",   cat:"Anti-Diabetic",  mfg:"Dr. Reddy's", stock:600,  reorder:200, expiry:"Jun 2027", price:5.50  },
  { name:"Atorvastatin 10mg", cat:"Lipid-Lowering", mfg:"Lupin",       stock:200,  reorder:150, expiry:"Jan 2027", price:12.00 },
  { name:"Ondansetron 4mg",   cat:"Antiemetic",     mfg:"Cipla",       stock:50,   reorder:100, expiry:"Nov 2026", price:18.00 },
];
const INIT_SURGERY = [
  { id:"SG-001", patient:"Ravi Kumar",  procedure:"Coronary Angioplasty", surgeon:"Dr. Rajesh Mehta", ot:"OT-1", datetime:"05 Apr, 08:00", status:"Completed" },
  { id:"SG-002", patient:"Arjun Rao",   procedure:"Knee Replacement",     surgeon:"Dr. Vikram Sharma",ot:"OT-2", datetime:"05 Apr, 15:00", status:"Scheduled" },
  { id:"SG-003", patient:"Mohan Das",   procedure:"Ureteroscopy",         surgeon:"Dr. Rajesh Mehta", ot:"OT-3", datetime:"06 Apr, 10:00", status:"Pending"   },
  { id:"SG-004", patient:"Suresh Menon",procedure:"Appendectomy",         surgeon:"Dr. Ramesh Gupta", ot:"OT-1", datetime:"07 Apr, 09:30", status:"Scheduled" },
];
const INIT_WARDS = [
  { name:"General Ward A", type:"General",     beds:30, occupied:24, rate:1500  },
  { name:"General Ward B", type:"General",     beds:30, occupied:18, rate:1500  },
  { name:"ICU",            type:"ICU",         beds:10, occupied:8,  rate:8000  },
  { name:"NICU",           type:"NICU",        beds:6,  occupied:3,  rate:10000 },
  { name:"Private Room",   type:"Private",     beds:15, occupied:12, rate:5000  },
  { name:"Semi-Private",   type:"Semi-Private",beds:20, occupied:14, rate:3000  },
  { name:"Maternity Ward", type:"Maternity",   beds:12, occupied:7,  rate:4000  },
];
const INIT_BLOOD = { "A+":42,"B+":38,"O+":15,"AB+":22,"A-":8,"B-":5,"O-":3,"AB-":6 };
const INIT_DONORS = [
  { name:"Arun Sharma", bg:"O+", units:2, date:"02 Apr 2026", status:"Verified", phone:"9811001111" },
  { name:"Lakshmi R.",  bg:"A+", units:1, date:"03 Apr 2026", status:"Verified", phone:"9811002222" },
  { name:"Karthik N.",  bg:"B+", units:1, date:"04 Apr 2026", status:"Testing",  phone:"9811003333" },
];
const INIT_STAFF = [
  { id:"ST-001", name:"Meena Pillai", role:"Head Nurse",       dept:"ICU",       shift:"Morning", salary:45000, phone:"9700001111", status:"Active"   },
  { id:"ST-002", name:"Rajesh Verma", role:"Lab Technician",   dept:"Pathology", shift:"Morning", salary:32000, phone:"9700002222", status:"Active"   },
  { id:"ST-003", name:"Sunita Devi",  role:"Pharmacist",       dept:"Pharmacy",  shift:"Evening", salary:38000, phone:"9700003333", status:"Active"   },
  { id:"ST-004", name:"Anil Kumar",   role:"Receptionist",     dept:"OPD",       shift:"Morning", salary:22000, phone:"9700004444", status:"Active"   },
  { id:"ST-005", name:"Priya Joshi",  role:"Nurse",            dept:"Ward A",    shift:"Night",   salary:35000, phone:"9700005555", status:"On Leave" },
  { id:"ST-006", name:"Deepak Singh", role:"Ambulance Driver", dept:"Emergency", shift:"Night",   salary:28000, phone:"9700006666", status:"Active"   },
];
const INIT_BILLING = [
  { inv:"INV-3001", patient:"Ravi Kumar",  services:"Surgery + Bed + Meds", total:85000, insurance:60000, mode:"Insurance", status:"Partial" },
  { inv:"INV-3002", patient:"Priya Singh", services:"OPD + Lab",            total:3500,  insurance:0,     mode:"UPI",       status:"Paid"    },
  { inv:"INV-3003", patient:"Sunita Nair", services:"MRI + Consult",        total:12000, insurance:8000,  mode:"Pending",   status:"Unpaid"  },
  { inv:"INV-3004", patient:"Mohan Das",   services:"Urology + Ward B",     total:28000, insurance:20000, mode:"Cash",      status:"Partial" },
];
const INIT_INVENTORY = [
  { name:"Surgical Gloves",  cat:"PPE",        qty:2400, unit:"Pairs",     reorder:500 },
  { name:"IV Drip Set",      cat:"Consumable", qty:180,  unit:"Pcs",       reorder:200 },
  { name:"Oxygen Cylinders", cat:"Equipment",  qty:45,   unit:"Cylinders", reorder:20  },
  { name:"N95 Masks",        cat:"PPE",        qty:300,  unit:"Pcs",       reorder:100 },
  { name:"Syringes 10ml",    cat:"Consumable", qty:90,   unit:"Pcs",       reorder:500 },
];
const INIT_AMBULANCE = [
  { id:"AMB-001", type:"ALS",      driver:"Suresh K.",  phone:"9900001111", location:"Koramangala",  status:"Dispatched" },
  { id:"AMB-002", type:"BLS",      driver:"Ramesh P.",  phone:"9900002222", location:"Hospital Base", status:"Available"  },
  { id:"AMB-003", type:"BLS",      driver:"Kishore V.", phone:"9900003333", location:"Indiranagar",  status:"Dispatched" },
  { id:"AMB-004", type:"Neonatal", driver:"Praveen S.", phone:"9900004444", location:"Hospital Base", status:"Available"  },
];
const INIT_NOTIFICATIONS = [
  { msg:"Surgery SG-002 scheduled today",      color:"info",    src:"Surgery",    read:false, time:"10 min ago" },
  { msg:"Blood stock O- critically low (3u)",  color:"danger",  src:"Blood Bank", read:false, time:"30 min ago" },
  { msg:"New patient P-1007 admitted",         color:"success", src:"Patients",   read:true,  time:"1 hr ago"   },
];
const INIT_AUDIT = [
  { msg:"Admin logged in",           color:"info",    time:"5 min ago"  },
  { msg:"Patient P-1001 admitted",   color:"success", time:"1 hr ago"   },
  { msg:"Surgery SG-001 completed",  color:"success", time:"2 hrs ago"  },
  { msg:"Low stock: Paracetamol",    color:"warning", time:"3 hrs ago"  },
  { msg:"Staff ST-005 on leave",     color:"danger",  time:"4 hrs ago"  },
];

// ─── HELPERS ─────────────────────────────────────────────────────────────────
const rupee = n => "₹" + n.toLocaleString("en-IN");
const today = () => new Date().toLocaleDateString("en-IN", { day:"2-digit", month:"short", year:"numeric" });
const statusColor = s => ({
  Admitted:"#1a63c8", Discharged:"#166534", OPD:"#155e75", Critical:"#9b1c1c",
  Confirmed:"#166534", Pending:"#92400e", "In Progress":"#1a63c8", Cancelled:"#9b1c1c",
  Completed:"#166534", Scheduled:"#1a63c8", Ready:"#166534", Processing:"#92400e",
  Active:"#166534", "On Duty":"#166534", "On Leave":"#92400e", "On Call":"#1a63c8",
  Available:"#166534", Dispatched:"#1a63c8", Paid:"#166534", Partial:"#92400e",
  Unpaid:"#9b1c1c", Verified:"#166534", Testing:"#92400e",
  "Follow-up":"#4c1d95", Emergency:"#9b1c1c", "Low Stock":"#9b1c1c", "In Stock":"#166534",
  Full:"#9b1c1c", High:"#92400e",
}[s] || "#92400e");
const statusBg = s => ({
  Admitted:"#dbeafe", Discharged:"#dcfce7", OPD:"#cffafe", Critical:"#fee2e2",
  Confirmed:"#dcfce7", Pending:"#fef3c7", "In Progress":"#dbeafe", Cancelled:"#fee2e2",
  Completed:"#dcfce7", Scheduled:"#dbeafe", Ready:"#dcfce7", Processing:"#fef3c7",
  Active:"#dcfce7", "On Duty":"#dcfce7", "On Leave":"#fef3c7", "On Call":"#dbeafe",
  Available:"#dcfce7", Dispatched:"#dbeafe", Paid:"#dcfce7", Partial:"#fef3c7",
  Unpaid:"#fee2e2", Verified:"#dcfce7", Testing:"#fef3c7",
  "Follow-up":"#ede9fe", Emergency:"#fee2e2", "Low Stock":"#fee2e2", "In Stock":"#dcfce7",
  Full:"#fee2e2", High:"#fef3c7",
}[s] || "#fef3c7");

function Badge({ s }) {
  return (
    <span style={{ background:statusBg(s), color:statusColor(s), padding:"2px 8px", borderRadius:20, fontSize:11, fontWeight:600, whiteSpace:"nowrap" }}>{s}</span>
  );
}

function Modal({ title, onClose, children, wide }) {
  return (
    <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.35)", display:"flex", alignItems:"center", justifyContent:"center", zIndex:9999 }}
      onClick={onClose}>
      <div style={{ background:"#fff", borderRadius:12, padding:24, width:wide||440, maxHeight:"88vh", overflowY:"auto", boxShadow:"0 12px 48px rgba(0,0,0,0.18)" }}
        onClick={e => e.stopPropagation()}>
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:18 }}>
          <div style={{ fontWeight:700, fontSize:15 }}>{title}</div>
          <button onClick={onClose} style={{ background:"none", border:"none", fontSize:18, cursor:"pointer", color:"#6b7280" }}>✕</button>
        </div>
        {children}
      </div>
    </div>
  );
}

function Input({ label, value, onChange, type="text", placeholder="" }) {
  return (
    <div style={{ marginBottom:12 }}>
      {label && <div style={{ fontSize:10, fontWeight:700, color:"#6b7280", textTransform:"uppercase", letterSpacing:"0.05em", marginBottom:4 }}>{label}</div>}
      <input value={value} onChange={e => onChange(e.target.value)} type={type} placeholder={placeholder}
        style={{ width:"100%", padding:"8px 10px", border:"1px solid #dde2eb", borderRadius:8, fontSize:13, fontFamily:"inherit", outline:"none", boxSizing:"border-box" }} />
    </div>
  );
}

function Sel({ label, value, onChange, options }) {
  return (
    <div style={{ marginBottom:12 }}>
      {label && <div style={{ fontSize:10, fontWeight:700, color:"#6b7280", textTransform:"uppercase", letterSpacing:"0.05em", marginBottom:4 }}>{label}</div>}
      <select value={value} onChange={e => onChange(e.target.value)}
        style={{ width:"100%", padding:"8px 10px", border:"1px solid #dde2eb", borderRadius:8, fontSize:13, fontFamily:"inherit", background:"#fff" }}>
        {options.map(o => <option key={o}>{o}</option>)}
      </select>
    </div>
  );
}

function Btn({ children, onClick, primary, danger, small }) {
  return (
    <button onClick={onClick} style={{
      padding: small ? "4px 10px" : "8px 16px", borderRadius:8, fontSize: small ? 11 : 13,
      fontWeight:600, cursor:"pointer", border:"1px solid",
      background: primary ? "#1a63c8" : danger ? "#fee2e2" : "#fff",
      color: primary ? "#fff" : danger ? "#9b1c1c" : "#374151",
      borderColor: primary ? "#1a63c8" : danger ? "#fecaca" : "#dde2eb",
      fontFamily:"inherit"
    }}>{children}</button>
  );
}

function Card({ children, style }) {
  return <div style={{ background:"#fff", border:"1px solid #e5e7eb", borderRadius:12, padding:16, boxShadow:"0 1px 4px rgba(0,0,0,0.07)", marginBottom:14, ...style }}>{children}</div>;
}

function StatCard({ label, value, sub, color, onClick }) {
  return (
    <div onClick={onClick} style={{ background:"#fff", border:"1px solid #e5e7eb", borderRadius:12, padding:"14px 16px", boxShadow:"0 1px 4px rgba(0,0,0,0.07)", cursor: onClick ? "pointer" : "default", borderLeft:`3px solid ${color||"#1a63c8"}` }}>
      <div style={{ fontSize:10, color:"#6b7280", fontWeight:700, textTransform:"uppercase", letterSpacing:"0.05em", marginBottom:4 }}>{label}</div>
      <div style={{ fontSize:26, fontWeight:800, color:color||"#1a1d24", lineHeight:1 }}>{value}</div>
      {sub && <div style={{ fontSize:11, color:"#6b7280", marginTop:6 }}>{sub}</div>}
    </div>
  );
}

function Table({ heads, rows }) {
  return (
    <div style={{ overflowX:"auto" }}>
      <table style={{ width:"100%", borderCollapse:"collapse", fontSize:12.5 }}>
        <thead>
          <tr style={{ borderBottom:"1px solid #e5e7eb" }}>
            {heads.map(h => <th key={h} style={{ textAlign:"left", padding:"7px 10px", fontSize:10.5, fontWeight:700, color:"#6b7280", textTransform:"uppercase", letterSpacing:"0.05em", whiteSpace:"nowrap" }}>{h}</th>)}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i} style={{ borderBottom: i < rows.length-1 ? "1px solid #f3f4f6" : "none" }}>
              {r.map((c, j) => <td key={j} style={{ padding:"8px 10px", verticalAlign:"middle", whiteSpace:"nowrap" }}>{c}</td>)}
            </tr>
          ))}
          {rows.length === 0 && (
            <tr><td colSpan={heads.length} style={{ textAlign:"center", padding:24, color:"#9ca3af", fontSize:13 }}>No data yet</td></tr>
          )}
        </tbody>
      </table>
    </div>
  );
}

function ProgressBar({ pct, color }) {
  return (
    <div style={{ height:6, background:"#f0f2f7", borderRadius:3, overflow:"hidden", marginTop:4 }}>
      <div style={{ height:"100%", width:`${Math.min(pct,100)}%`, background:color||"#1a63c8", borderRadius:3, transition:"width 0.7s" }} />
    </div>
  );
}

// ─── PAGES ───────────────────────────────────────────────────────────────────

function Dashboard({ state, setPage, addAudit, addNotif }) {
  const patients=state.patients||[], doctors=state.doctors||[], appointments=state.appointments||[], billing=state.billing||[], wards=state.wards||[], bloodStock=state.bloodStock||{}, labReports=state.labReports||[], surgeries=state.surgeries||[], ambulance=state.ambulance||[], staff=state.staff||[], notifications=state.notifications||[], auditLog=state.auditLog||[];
  const [tick, setTick] = useState(0);
  useEffect(() => { const id = setInterval(() => setTick(t=>t+1), 30000); return () => clearInterval(id); }, []);

  const now = new Date();
  const clockStr = now.toLocaleTimeString("en-IN", { hour:"2-digit", minute:"2-digit" });
  const dateStr  = now.toLocaleDateString("en-IN", { weekday:"long", day:"numeric", month:"long", year:"numeric" });

  const admitted      = patients.filter(p => p.status === "Admitted").length;
  const critical      = patients.filter(p => p.status === "Critical").length;
  const discharged    = patients.filter(p => p.status === "Discharged").length;
  const onDuty        = doctors.filter(d => d.status === "On Duty").length;
  const pendingAppts  = appointments.filter(a => a.status === "Pending").length;
  const paidRev       = billing.filter(b => b.status === "Paid").reduce((s,b) => s+b.total, 0);
  const pendingDues   = billing.filter(b => b.status !== "Paid").reduce((s,b) => s+Math.max(0,b.total-b.insurance), 0);
  const totalBeds     = wards.reduce((s,w) => s+w.beds, 0);
  const occupiedBeds  = wards.reduce((s,w) => s+w.occupied, 0);
  const bedPct        = totalBeds > 0 ? Math.round((occupiedBeds/totalBeds)*100) : 0;
  const lowMeds       = state.pharmacy.filter(m => m.stock < m.reorder).length;
  const critBlood     = Object.entries(bloodStock).filter(([,u]) => u < 8);
  const pendingLab    = labReports.filter(l => l.status === "Pending" || l.status === "Processing").length;
  const scheduledSurg = surgeries.filter(s => s.status !== "Completed").length;
  const dispatchedAmb = ambulance.filter(a => a.status === "Dispatched").length;
  const unread        = notifications.filter(n => !n.read).length;
  const dotC = { success:"#22c55e", warning:"#f59e0b", danger:"#ef4444", info:"#1a63c8" };
  const fmt = n => n >= 100000 ? "₹"+(n/100000).toFixed(1)+"L" : rupee(n);

  const deptCounts = {};
  patients.forEach(p => { deptCounts[p.dept] = (deptCounts[p.dept]||0)+1; });
  const topDepts = Object.entries(deptCounts).sort((a,b)=>b[1]-a[1]).slice(0,5);
  const deptColors = ["#1a63c8","#9b1c1c","#92400e","#166534","#4c1d95"];

  return (
    <div style={{ animation:"fadeIn 0.3s" }}>
      {/* Header */}
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:16, padding:"4px 0" }}>
        <div>
          <div style={{ fontSize:16, fontWeight:800, color:"#1a1d24" }}>Hospital Dashboard</div>
          <div style={{ fontSize:11, color:"#6b7280", marginTop:2 }}>{dateStr}</div>
        </div>
        <div style={{ textAlign:"right" }}>
          <div style={{ fontSize:24, fontWeight:800, color:"#1a63c8", fontFamily:"monospace" }}>{clockStr}</div>
          <div style={{ fontSize:10, color:"#9ca3af" }}>● Live data</div>
        </div>
      </div>

      {/* Row 1 — 4 primary KPIs */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:12, marginBottom:12 }}>
        <StatCard label="Total Patients" value={patients.length} color="#1a63c8"
          sub={`${admitted} admitted · ${critical} critical · ${discharged} discharged`} onClick={() => setPage("patients")} />
        <StatCard label="Doctors On Duty" value={onDuty} color="#166534"
          sub={`${doctors.length - onDuty} off · ${doctors.length} total`} onClick={() => setPage("doctors")} />
        <StatCard label="Appointments" value={appointments.length} color="#92400e"
          sub={`${pendingAppts} pending · ${appointments.length - pendingAppts} confirmed`} onClick={() => setPage("appointments")} />
        <StatCard label="Total Billing" value={fmt(paidRev + pendingDues)} color="#9b1c1c"
          sub={`${fmt(paidRev)} paid · ${fmt(pendingDues)} due`} onClick={() => setPage("billing")} />
      </div>

      {/* Row 2 — secondary KPIs */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:12, marginBottom:12 }}>
        <div style={{ background:"#fff", border:"1px solid #e5e7eb", borderRadius:12, padding:"14px 16px", boxShadow:"0 1px 4px rgba(0,0,0,0.07)", borderLeft:"3px solid #1a63c8", cursor:"pointer" }} onClick={() => setPage("rooms")}>
          <div style={{ fontSize:10, color:"#6b7280", fontWeight:700, textTransform:"uppercase", letterSpacing:"0.05em", marginBottom:4 }}>Bed Occupancy</div>
          <div style={{ fontSize:26, fontWeight:800, color:"#1a63c8" }}>{bedPct}%</div>
          <div style={{ fontSize:11, color:"#6b7280", marginTop:4 }}>{occupiedBeds}/{totalBeds} beds · {totalBeds-occupiedBeds} free</div>
          <ProgressBar pct={bedPct} color={bedPct>=90?"#9b1c1c":bedPct>=70?"#92400e":"#1a63c8"} />
        </div>
        <StatCard label="Pharmacy Alerts" value={lowMeds} color="#92400e"
          sub="medicines below reorder" onClick={() => setPage("pharmacy")} />
        <StatCard label="Blood Bank" value={critBlood.length > 0 ? `${critBlood.length} Critical` : "✓ OK"} color={critBlood.length > 0 ? "#9b1c1c" : "#166534"}
          sub={critBlood.length > 0 ? critBlood.map(([bg,u]) => `${bg}(${u}u)`).join(" · ") : "All groups stocked"} onClick={() => setPage("blood")} />
        <StatCard label="Active Staff" value={staff.filter(s=>s.status==="Active").length} color="#166534"
          sub={`${staff.length} total · ${staff.filter(s=>s.status==="On Leave").length} on leave`} onClick={() => setPage("staff")} />
      </div>

      {/* Row 3 — mini tiles + dept chart */}
      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12, marginBottom:12 }}>
        <Card>
          <div style={{ fontWeight:700, fontSize:13, marginBottom:12 }}>Live Module Summary</div>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:8 }}>
            {[
              { label:"Lab Pending",      val:pendingLab,                             col:"#92400e", page:"lab"           },
              { label:"Surgery Sched.",   val:scheduledSurg,                          col:"#1a63c8", page:"surgery"       },
              { label:"Ambulance Out",    val:dispatchedAmb,                          col:"#9b1c1c", page:"ambulance"     },
              { label:"Invoices Unpaid",  val:billing.filter(b=>b.status!=="Paid").length, col:"#92400e", page:"billing" },
              { label:"Notifications",    val:unread,                                 col:unread>0?"#9b1c1c":"#166534", page:"notifications" },
              { label:"OPD Patients",     val:patients.filter(p=>p.status==="OPD").length, col:"#1a63c8", page:"patients"  },
            ].map(item => (
              <div key={item.label} onClick={() => setPage(item.page)} style={{ background:"#f8faff", borderRadius:8, padding:10, cursor:"pointer" }}>
                <div style={{ fontSize:9, color:"#9ca3af", fontWeight:700, textTransform:"uppercase", letterSpacing:"0.05em" }}>{item.label}</div>
                <div style={{ fontSize:22, fontWeight:800, color:item.col, marginTop:2 }}>{item.val}</div>
              </div>
            ))}
          </div>
        </Card>
        <Card>
          <div style={{ fontWeight:700, fontSize:13, marginBottom:12 }}>Patient Distribution</div>
          <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
            {topDepts.map(([dept, count], i) => {
              const pct = Math.round((count / Math.max(patients.length,1)) * 100);
              return (
                <div key={dept}>
                  <div style={{ display:"flex", justifyContent:"space-between", fontSize:12, marginBottom:2 }}>
                    <span>{dept}</span>
                    <span style={{ color:"#6b7280" }}>{count} ({pct}%)</span>
                  </div>
                  <ProgressBar pct={pct} color={deptColors[i]} />
                </div>
              );
            })}
          </div>
        </Card>
      </div>

      {/* Row 4 — Activity + Appointments */}
      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12, marginBottom:12 }}>
        <Card>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:10 }}>
            <div style={{ fontWeight:700, fontSize:13 }}>Recent Activity</div>
            <Btn small onClick={() => setPage("admin")}>Audit Log</Btn>
          </div>
          {auditLog.slice(0,6).map((a,i) => (
            <div key={i} style={{ display:"flex", gap:10, padding:"7px 0", borderBottom: i<5?"1px solid #f3f4f6":"none" }}>
              <div style={{ width:8, height:8, borderRadius:"50%", background:dotC[a.color]||"#1a63c8", marginTop:4, flexShrink:0 }} />
              <div>
                <div style={{ fontSize:12.5 }}>{a.msg}</div>
                <div style={{ fontSize:10.5, color:"#9ca3af", marginTop:2 }}>{a.time}</div>
              </div>
            </div>
          ))}
        </Card>
        <Card>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:10 }}>
            <div style={{ fontWeight:700, fontSize:13 }}>Today's Appointments ({appointments.length})</div>
            <Btn small onClick={() => setPage("appointments")}>View All</Btn>
          </div>
          <Table heads={["Patient","Doctor","Time","Status"]}
            rows={appointments.slice(0,4).map(a => [a.patient, a.doctor, a.time, <Badge s={a.status} />])} />
        </Card>
      </div>

      {/* Row 5 — Recent Patients */}
      <Card>
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:10 }}>
          <div style={{ fontWeight:700, fontSize:13 }}>Recent Patients ({patients.length} total)</div>
          <Btn small onClick={() => setPage("patients")}>View All</Btn>
        </div>
        <Table heads={["ID","Name","Age","Dept","Doctor","Admitted","Status"]}
          rows={[...patients].reverse().slice(0,5).map(p => [p.id, p.fname+" "+p.lname, p.age, p.dept, p.doctor, p.admitted, <Badge s={p.status} />])} />
      </Card>

      {/* Row 6 — Blood Bank + Surgeries */}
      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12 }}>
        <Card>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:10 }}>
            <div style={{ fontWeight:700, fontSize:13 }}>Blood Bank{critBlood.length>0&&<span style={{ color:"#9b1c1c", fontSize:11, marginLeft:8 }}>⚠ {critBlood.length} critical</span>}</div>
            <Btn small onClick={() => setPage("blood")}>Manage</Btn>
          </div>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:8 }}>
            {["A+","B+","O+","AB+","A-","B-","O-","AB-"].map(bg => {
              const u = bloodStock[bg]||0;
              const low = u < 8;
              return (
                <div key={bg} style={{ textAlign:"center", padding:"8px 4px", borderRadius:8, border:`1px solid ${low?"#fca5a5":"#e5e7eb"}`, background:low?"#fef2f2":"#f9fafb" }}>
                  <div style={{ fontWeight:800, fontSize:14, color:low?"#9b1c1c":"#1a1d24" }}>{bg}</div>
                  <div style={{ fontSize:10.5, color:low?"#9b1c1c":"#6b7280", marginTop:2 }}>{u}u{low?" ⚠":""}</div>
                </div>
              );
            })}
          </div>
        </Card>
        <Card>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:10 }}>
            <div style={{ fontWeight:700, fontSize:13 }}>Upcoming Surgeries ({scheduledSurg})</div>
            <Btn small onClick={() => setPage("surgery")}>View All</Btn>
          </div>
          <Table heads={["ID","Patient","Procedure","OT","Status"]}
            rows={surgeries.filter(s=>s.status!=="Completed").slice(0,4).map(s => [s.id, s.patient, s.procedure, s.ot, <Badge s={s.status} />])} />
        </Card>
      </div>
    </div>
  );
}

function PatientsPage({ state, setState, toast, addAudit, currentUser }) {
  const [search, setSearch] = useState("");
  const [showAdd, setShowAdd] = useState(false);
  const [editId, setEditId] = useState(null);
  const [viewId, setViewId] = useState(null);
  const [form, setForm] = useState({ fname:"", lname:"", age:"", gender:"Male", dept:"Cardiology", doctor:"Dr. Rajesh Mehta", blood:"A+", status:"OPD", phone:"" });
  const f = k => v => setForm(p => ({...p,[k]:v}));
  const depts = ["Cardiology","Neurology","Orthopaedics","Paediatrics","Gynaecology","Urology","Gastrology"];
  const filtered = state.patients.filter(p => !search || (p.fname+" "+p.lname).toLowerCase().includes(search.toLowerCase()) || p.id.toLowerCase().includes(search.toLowerCase()));

  const handleAdd = () => {
    if(!form.fname||!form.lname){toast("Name required");return;}
    const nums = state.patients.map(p=>parseInt(p.id.replace(/\D/g,""))).filter(n=>!isNaN(n));
    const id = "P-"+(Math.max(0,...nums)+1);
    const newP = {...form, id, age:parseInt(form.age)||0, admitted:today(), email:"", admType:"OPD"};
    setState(s=>({...s, patients:[...s.patients, newP]}));
    addAudit(`Patient ${id} registered — ${form.dept}`, "success");
    setShowAdd(false); setForm({ fname:"", lname:"", age:"", gender:"Male", dept:"Cardiology", doctor:"Dr. Rajesh Mehta", blood:"A+", status:"OPD", phone:"" });
    toast(`✓ Patient ${id} added!`);
  };
  const handleEdit = () => {
    setState(s=>({...s, patients:s.patients.map(p=>p.id===editId?{...p,...form,age:parseInt(form.age)||p.age}:p)}));
    addAudit(`Patient ${editId} updated`, "info");
    setEditId(null); toast(`✓ Patient ${editId} updated`);
  };
  const openEdit = id => {
    const p = state.patients.find(x=>x.id===id);
    setForm({fname:p.fname,lname:p.lname,age:String(p.age),gender:p.gender,dept:p.dept,doctor:p.doctor,blood:p.blood,status:p.status,phone:p.phone||""});
    setEditId(id);
  };
  const viewP = viewId ? state.patients.find(p=>p.id===viewId) : null;

  return (
    <div>
      <div style={{ display:"flex", gap:8, marginBottom:12, alignItems:"center" }}>
        <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search patient…"
          style={{ padding:"8px 12px", border:"1px solid #dde2eb", borderRadius:8, fontSize:13, width:220, fontFamily:"inherit" }} />
        <div style={{ flex:1 }}/>
        {(!currentUser || currentUser.role !== 'Patient') && <Btn primary onClick={()=>setShowAdd(true)}>+ Add Patient</Btn>}
      </div>
      <Card>
        <Table heads={["ID","Name","Age","Gender","Dept","Doctor","Admitted","Status","Actions"]}
          rows={filtered.map(p => [p.id, p.fname+" "+p.lname, p.age, p.gender[0], p.dept, p.doctor, p.admitted, <Badge s={p.status}/>,
            currentUser?.role === 'Patient' ? <Btn small onClick={()=>setViewId(p.id)}>View</Btn> : <div style={{display:"flex",gap:4}}><Btn small onClick={()=>setViewId(p.id)}>View</Btn><Btn small primary onClick={()=>openEdit(p.id)}>Edit</Btn></div>])} />
      </Card>

      {(showAdd||editId) && (
        <Modal title={editId?`Edit Patient — ${editId}`:"Register New Patient"} onClose={()=>{setShowAdd(false);setEditId(null);}}>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
            <Input label="First Name" value={form.fname} onChange={f("fname")} />
            <Input label="Last Name" value={form.lname} onChange={f("lname")} />
            <Input label="Age" type="number" value={form.age} onChange={f("age")} />
            <Sel label="Gender" value={form.gender} onChange={f("gender")} options={["Male","Female","Other"]} />
            <Input label="Phone" value={form.phone} onChange={f("phone")} />
            <Sel label="Blood Group" value={form.blood} onChange={f("blood")} options={["A+","B+","O+","AB+","A-","B-","O-","AB-"]} />
            <Sel label="Department" value={form.dept} onChange={f("dept")} options={depts} />
            <Sel label="Status" value={form.status} onChange={f("status")} options={["Admitted","Discharged","OPD","Critical"]} />
          </div>
          <div style={{display:"flex",gap:8,marginTop:8}}><Btn primary onClick={editId?handleEdit:handleAdd}>{editId?"Save Changes":"Register Patient"}</Btn><Btn onClick={()=>{setShowAdd(false);setEditId(null);}}>Cancel</Btn></div>
        </Modal>
      )}
      {viewP && (
        <Modal title={`Patient — ${viewP.id}`} onClose={()=>setViewId(null)}>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12,fontSize:13}}>
            {[["Name",viewP.fname+" "+viewP.lname],["Age/Gender",`${viewP.age} / ${viewP.gender}`],["Department",viewP.dept],["Doctor",viewP.doctor],["Blood Group",viewP.blood],["Phone",viewP.phone||"—"],["Admitted",viewP.admitted],["Status",<Badge s={viewP.status}/>]].map(([k,v])=>
              <div key={k}><div style={{fontSize:10,color:"#6b7280",fontWeight:700,textTransform:"uppercase",marginBottom:2}}>{k}</div><div style={{fontWeight:500}}>{v}</div></div>)}
          </div>
          <div style={{marginTop:16,textAlign:"right"}}><Btn onClick={()=>setViewId(null)}>Close</Btn></div>
        </Modal>
      )}
    </div>
  );
}

function DoctorsPage({ state, setState, toast, addAudit, currentUser }) {
  const [showAdd, setShowAdd] = useState(false);
  const [editId, setEditId] = useState(null);
  const [viewId, setViewId] = useState(null);
  const [form, setForm] = useState({ name:"", spec:"Cardiology", qual:"", exp:"", phone:"", status:"On Duty" });
  const f = k => v => setForm(p=>({...p,[k]:v}));
  const specs = ["Cardiology","Neurology","Orthopaedics","Paediatrics","Gynaecology","Urology","Gastrology","Radiology","General Medicine"];
  const viewD = viewId ? state.doctors.find(d=>d.id===viewId) : null;

  const handleAdd = () => {
    if(!form.name){toast("Name required");return;}
    const nums = state.doctors.map(d=>parseInt(d.id.replace(/\D/g,""))).filter(n=>!isNaN(n));
    const id = "D-"+String(Math.max(0,...nums)+1).padStart(3,"0");
    const full = form.name.startsWith("Dr.") ? form.name : "Dr. "+form.name;
    setState(s=>({...s,doctors:[...s.doctors,{...form,name:full,id,today:0}]}));
    addAudit(`Doctor ${id} registered — ${form.spec}`,"success");
    setShowAdd(false); setForm({name:"",spec:"Cardiology",qual:"",exp:"",phone:"",status:"On Duty"});
    toast(`✓ ${full} added!`);
  };
  const handleEdit = () => {
    setState(s=>({...s,doctors:s.doctors.map(d=>d.id===editId?{...d,...form}:d)}));
    addAudit(`Doctor ${editId} updated`,"info");
    setEditId(null); toast("✓ Doctor updated");
  };
  const openEdit = id => { const d=state.doctors.find(x=>x.id===id); setForm({name:d.name,spec:d.spec,qual:d.qual,exp:d.exp,phone:d.phone,status:d.status}); setEditId(id); };

  return (
    <div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:12,marginBottom:12}}>
        <StatCard label="Total Doctors" value={state.doctors.length} color="#1a63c8" />
        <StatCard label="On Duty" value={state.doctors.filter(d=>d.status==="On Duty").length} color="#166534" />
        <StatCard label="Today's Patients" value={state.doctors.reduce((s,d)=>s+d.today,0)} color="#92400e" />
      </div>
      {currentUser?.role !== 'Patient' && (
        <div style={{display:"flex",justifyContent:"flex-end",marginBottom:12}}>
          <Btn primary onClick={()=>setShowAdd(true)}>+ Add Doctor</Btn>
        </div>
      )}
      <Card>
        <Table heads={["ID","Name","Specialisation","Qualification","Exp","Phone","Status","Actions"]}
          rows={state.doctors.map(d=>[d.id,d.name,d.spec,d.qual,d.exp,d.phone,<Badge s={d.status}/>,
            currentUser?.role === 'Patient'
              ? <Btn small onClick={()=>setViewId(d.id)}>Profile</Btn>
              : <div style={{display:"flex",gap:4}}><Btn small onClick={()=>setViewId(d.id)}>Profile</Btn><Btn small primary onClick={()=>openEdit(d.id)}>Edit</Btn></div>])} />
      </Card>
      {(showAdd||editId) && (
        <Modal title={editId?`Edit Doctor — ${editId}`:"Add New Doctor"} onClose={()=>{setShowAdd(false);setEditId(null);}}>
          <Input label="Full Name *" value={form.name} onChange={f("name")} placeholder="Dr. Priya Sharma" />
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
            <Sel label="Specialisation *" value={form.spec} onChange={f("spec")} options={specs} />
            <Input label="Qualification" value={form.qual} onChange={f("qual")} placeholder="MD, DM" />
            <Input label="Experience" value={form.exp} onChange={f("exp")} placeholder="10 yrs" />
            <Input label="Phone" value={form.phone} onChange={f("phone")} />
            <Sel label="Status" value={form.status} onChange={f("status")} options={["On Duty","On Leave","Off Duty","On Call"]} />
          </div>
          <div style={{display:"flex",gap:8,marginTop:8}}><Btn primary onClick={editId?handleEdit:handleAdd}>{editId?"Save":"Add Doctor"}</Btn><Btn onClick={()=>{setShowAdd(false);setEditId(null);}}>Cancel</Btn></div>
        </Modal>
      )}
      {viewD && (
        <Modal title={`Doctor Profile — ${viewD.id}`} onClose={()=>setViewId(null)}>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12,fontSize:13}}>
            {[["Name",viewD.name],["Specialisation",viewD.spec],["Qualification",viewD.qual],["Experience",viewD.exp],["Phone",viewD.phone],["Status",<Badge s={viewD.status}/>],["Today's Patients",viewD.today]].map(([k,v])=>
              <div key={k}><div style={{fontSize:10,color:"#6b7280",fontWeight:700,textTransform:"uppercase",marginBottom:2}}>{k}</div><div style={{fontWeight:500}}>{v}</div></div>)}
          </div>
          <div style={{marginTop:16,display:"flex",gap:8,justifyContent:"flex-end"}}>{currentUser?.role !== 'Patient' && <Btn primary onClick={()=>{setViewId(null);openEdit(viewD.id);}}>Edit</Btn>}<Btn onClick={()=>setViewId(null)}>Close</Btn></div>
        </Modal>
      )}
    </div>
  );
}

function AppointmentsPage({ state, setState, toast, addAudit, addNotif, currentUser }) {
  const [showAdd, setShowAdd] = useState(false);
  const [tab, setTab]         = useState('all'); // 'all' | 'pending' | 'mine'
  const [form, setForm]       = useState({ patient:'', doctor:'Dr. Rajesh Mehta', dept:'Cardiology', date:new Date().toISOString().slice(0,10), time:'', type:'OPD' });
  const f = k => v => setForm(p => ({ ...p, [k]: v }));
  const role = currentUser?.role || 'Admin';

  // When Patient books → status is always "Pending" (awaiting doctor acceptance)
  const handleAdd = () => {
    if (!form.patient || !form.date) { toast('Patient name and date required'); return; }
    const nums  = state.appointments.map(a => parseInt(a.token.replace(/\D/g, ''))).filter(n => !isNaN(n));
    const token = '#T' + (Math.max(0, ...nums) + 1);
    const dateStr = new Date(form.date).toLocaleDateString('en-IN', { day:'2-digit', month:'short' });
    const newStatus = role === 'Patient' ? 'Pending' : 'Confirmed';
    setState(s => ({ ...s, appointments: [...s.appointments, { token, patient: form.patient, pid:'CUSTOM', doctor: form.doctor, dept: form.dept, date: dateStr, time: form.time, type: form.type, status: newStatus }] }));
    addAudit('Appointment ' + token + ' booked by ' + (currentUser?.name || role), 'success');
    if (role === 'Patient') {
      addNotif('New appointment request ' + token + ' from ' + form.patient + ' — awaiting doctor approval', 'warning', 'Appointments');
      toast('✓ Appointment ' + token + ' requested! Awaiting doctor acceptance.');
    } else {
      toast('✓ Appointment ' + token + ' booked!');
    }
    setShowAdd(false);
    setForm({ patient:'', doctor:'Dr. Rajesh Mehta', dept:'Cardiology', date:new Date().toISOString().slice(0,10), time:'', type:'OPD' });
  };

  const accept = (token) => {
    setState(s => ({ ...s, appointments: s.appointments.map(a => a.token === token ? { ...a, status:'Confirmed' } : a) }));
    addAudit('Appointment ' + token + ' accepted', 'success');
    addNotif('Appointment ' + token + ' has been accepted by the doctor', 'success', 'Appointments');
    toast('✓ Appointment ' + token + ' accepted');
  };

  const reject = (token) => {
    setState(s => ({ ...s, appointments: s.appointments.map(a => a.token === token ? { ...a, status:'Cancelled' } : a) }));
    addAudit('Appointment ' + token + ' rejected', 'danger');
    addNotif('Appointment ' + token + ' was rejected', 'danger', 'Appointments');
    toast('✓ Appointment ' + token + ' rejected');
  };

  const cancel = (token) => {
    setState(s => ({ ...s, appointments: s.appointments.map(a => a.token === token ? { ...a, status:'Cancelled' } : a) }));
    addAudit('Appointment ' + token + ' cancelled', 'danger');
    toast('✓ Appointment cancelled');
  };

  const complete = (token) => {
    setState(s => ({ ...s, appointments: s.appointments.map(a => a.token === token ? { ...a, status:'Completed' } : a) }));
    addAudit('Appointment ' + token + ' completed', 'success');
    toast('✓ Marked as completed');
  };

  // Filter appointments by role
  const allAppts = state.appointments;
  const pending  = allAppts.filter(a => a.status === 'Pending');
  const myAppts  = role === 'Doctor'
    ? allAppts.filter(a => a.doctor === currentUser?.name)
    : role === 'Patient'
    ? allAppts.filter(a => a.patient === currentUser?.name)
    : allAppts;

  const displayed = tab === 'pending' ? pending : tab === 'mine' ? myAppts : allAppts;

  // Action buttons per role per status
  const actionBtns = (a) => {
    // Accept / Reject — DOCTOR ONLY
    if (role === 'Doctor') {
      if (a.status === 'Pending')
        return (
          <div style={{display:'flex',gap:4}}>
            <button onClick={() => accept(a.token)} style={{padding:'3px 10px',borderRadius:6,border:'none',background:'#166534',color:'#fff',fontSize:11,fontWeight:600,cursor:'pointer',fontFamily:'inherit'}}>✓ Accept</button>
            <button onClick={() => reject(a.token)} style={{padding:'3px 10px',borderRadius:6,border:'none',background:'#9b1c1c',color:'#fff',fontSize:11,fontWeight:600,cursor:'pointer',fontFamily:'inherit'}}>✗ Reject</button>
          </div>
        );
      if (a.status === 'Confirmed')
        return <button onClick={() => complete(a.token)} style={{padding:'3px 10px',borderRadius:6,border:'1px solid #1a63c8',background:'#fff',color:'#1a63c8',fontSize:11,fontWeight:600,cursor:'pointer',fontFamily:'inherit'}}>Complete</button>;
      return <span style={{color:'#9ca3af',fontSize:11}}>{a.status}</span>;
    }
    // Patient — show status text only
    if (role === 'Patient') {
      if (a.status === 'Pending')   return <span style={{color:'#92400e',fontSize:11,fontWeight:600}}>⏳ Awaiting Doctor</span>;
      if (a.status === 'Confirmed') return <span style={{color:'#166534',fontSize:11,fontWeight:600}}>✓ Confirmed</span>;
      if (a.status === 'Completed') return <span style={{color:'#1a63c8',fontSize:11,fontWeight:600}}>✓ Completed</span>;
      if (a.status === 'Cancelled') return <span style={{color:'#9b1c1c',fontSize:11,fontWeight:600}}>✗ Cancelled</span>;
      return <span style={{color:'#9ca3af',fontSize:11}}>{a.status}</span>;
    }
    // Admin / Staff — view status, can Cancel confirmed, but NO Accept/Reject
    if (a.status === 'Pending')
      return <span style={{color:'#92400e',fontSize:11,fontWeight:600}}>⏳ Awaiting Doctor</span>;
    if (a.status === 'Confirmed')
      return (
        <div style={{display:'flex',gap:4}}>
          <button onClick={() => complete(a.token)} style={{padding:'3px 8px',borderRadius:6,border:'1px solid #1a63c8',background:'#fff',color:'#1a63c8',fontSize:11,fontWeight:600,cursor:'pointer',fontFamily:'inherit'}}>Complete</button>
          <button onClick={() => cancel(a.token)} style={{padding:'3px 8px',borderRadius:6,border:'none',background:'#fee2e2',color:'#9b1c1c',fontSize:11,fontWeight:600,cursor:'pointer',fontFamily:'inherit'}}>Cancel</button>
        </div>
      );
    if (a.status === 'Completed') return <span style={{color:'#166534',fontSize:11,fontWeight:600}}>✓ Completed</span>;
    if (a.status === 'Cancelled') return <span style={{color:'#9b1c1c',fontSize:11,fontWeight:600}}>✗ Cancelled</span>;
    return <span style={{color:'#9ca3af',fontSize:11}}>{a.status}</span>;
  };

  const tabBtn = (id, label, count, color) => (
    <button onClick={() => setTab(id)} style={{
      padding:'6px 14px', borderRadius:8, border:'1px solid', fontFamily:'inherit',
      fontSize:12, fontWeight:600, cursor:'pointer',
      background: tab===id ? '#1a63c8' : '#fff',
      color:       tab===id ? '#fff'    : '#6b7280',
      borderColor: tab===id ? '#1a63c8' : '#e5e7eb',
    }}>
      {label} {count > 0 && <span style={{marginLeft:4,background:tab===id?'rgba(255,255,255,0.3)':color,color:tab===id?'#fff':'#fff',borderRadius:20,padding:'1px 7px',fontSize:10}}>{count}</span>}
    </button>
  );

  return (
    <div>
      {/* KPI row */}
      <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:12,marginBottom:14}}>
        <StatCard label='Total'     value={allAppts.length}                                       color='#1a63c8'/>
        <StatCard label='Pending'   value={pending.length}                                        color='#92400e'
          sub={pending.length > 0 ? 'Awaiting acceptance' : 'None waiting'}/>
        <StatCard label='Confirmed' value={allAppts.filter(a=>a.status==='Confirmed').length}     color='#166534'/>
        <StatCard label='Completed' value={allAppts.filter(a=>a.status==='Completed').length}     color='#1a63c8'/>
      </div>

      {/* Pending alert banner — Doctor only */}
      {pending.length > 0 && role === 'Doctor' && (
        <div style={{background:'#fef3c7',border:'1px solid #fde68a',borderRadius:10,padding:'12px 16px',marginBottom:14,display:'flex',alignItems:'center',gap:12}}>
          <span style={{fontSize:20}}>⚠️</span>
          <div>
            <div style={{fontWeight:700,fontSize:13,color:'#92400e'}}>{pending.length} appointment{pending.length>1?'s':''} waiting for acceptance</div>
            <div style={{fontSize:12,color:'#92400e',marginTop:2}}>
              {pending.map(a => a.patient + ' → ' + a.doctor).join('  ·  ')}
            </div>
          </div>
          <button onClick={() => setTab('pending')} style={{marginLeft:'auto',padding:'6px 14px',borderRadius:8,border:'none',background:'#92400e',color:'#fff',fontSize:12,fontWeight:600,cursor:'pointer',fontFamily:'inherit'}}>
            Review Now
          </button>
        </div>
      )}

      {/* Tab bar + Book button */}
      <div style={{display:'flex',gap:8,marginBottom:14,alignItems:'center',flexWrap:'wrap'}}>
        {tabBtn('all',   'All Appointments', 0, '#1a63c8')}
        {tabBtn('pending','⏳ Pending',       pending.length, '#92400e')}
        {(role === 'Doctor' || role === 'Patient') && tabBtn('mine', role==='Doctor'?'My Patients':'My Appointments', myAppts.length, '#166534')}
        <div style={{flex:1}}/>
        <button onClick={() => setShowAdd(true)} style={{padding:'7px 16px',borderRadius:8,border:'none',background:'#1a63c8',color:'#fff',fontSize:13,fontWeight:600,cursor:'pointer',fontFamily:'inherit'}}>
          + Book Appointment
        </button>
      </div>

      {/* Table */}
      <Card>
        <Table
          heads={['Token','Patient','Doctor','Dept','Date','Time','Type','Status','Action']}
          rows={displayed.map(a => [
            a.token,
            <span style={{fontWeight:500}}>{a.patient}</span>,
            a.doctor, a.dept, a.date,
            a.time || '—',
            <Badge s={a.type}/>,
            <Badge s={a.status}/>,
            actionBtns(a)
          ])}
        />
        {displayed.length === 0 && (
          <div style={{textAlign:'center',padding:'24px',color:'#9ca3af',fontSize:13}}>
            {tab === 'pending' ? 'No pending appointments — all caught up! ✓' : 'No appointments found'}
          </div>
        )}
      </Card>

      {/* Book Modal */}
      {showAdd && (
        <Modal title='Book Appointment' onClose={() => setShowAdd(false)}>
          {role === 'Patient' && (
            <div style={{background:'#eff6ff',border:'1px solid #bfdbfe',borderRadius:8,padding:'10px 14px',marginBottom:12,fontSize:12,color:'#1a63c8'}}>
              ℹ️ Your appointment will be sent for doctor approval. You'll see it confirmed once accepted.
            </div>
          )}
          <Input label='Patient Name *' value={form.patient} onChange={f('patient')} />
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10}}>
            <Sel label='Doctor'  value={form.doctor}  onChange={f('doctor')}  options={state.doctors.map(d => d.name)} />
            <Sel label='Type'    value={form.type}    onChange={f('type')}    options={['OPD','Follow-up','Emergency']} />
            <div style={{gridColumn:'1/-1'}}>
              <label style={{fontSize:10,fontWeight:700,color:'#6b7280',textTransform:'uppercase',letterSpacing:'0.05em',display:'block',marginBottom:4}}>Date *</label>
              <input type='date' value={form.date} min={new Date().toISOString().slice(0,10)}
                onChange={e=>setForm(p=>({...p,date:e.target.value,time:''}))}
                style={{width:'100%',padding:'8px 10px',border:'1px solid #dde2eb',borderRadius:8,fontSize:13,fontFamily:'inherit',boxSizing:'border-box'}} />
            </div>
            <div style={{gridColumn:'1/-1'}}>
              <label style={{fontSize:10,fontWeight:700,color:'#6b7280',textTransform:'uppercase',letterSpacing:'0.05em',display:'block',marginBottom:6}}>
                Available Time Slots
                {form.date && <span style={{fontSize:10,color:'#9ca3af',marginLeft:6,fontWeight:400}}>
                  {new Date(form.date).toLocaleDateString('en-IN',{weekday:'long',day:'numeric',month:'short'})}
                </span>}
              </label>
              {!form.date
                ? <div style={{fontSize:12,color:'#9ca3af',padding:'10px 0'}}>Please select a date first</div>
                : (() => {
                    const now        = new Date();
                    const selDate    = new Date(form.date);
                    const isToday    = selDate.toDateString() === now.toDateString();
                    const nowHour    = now.getHours();
                    const nowMin     = now.getMinutes();
                    const slots      = ['09:00','09:30','10:00','10:30','11:00','11:30','12:00','12:30','14:00','14:30','15:00','15:30','16:00','16:30','17:00','17:30'];
                    const bookedSlots= state.appointments
                      .filter(a => {
                        const aDate = new Date(form.date).toLocaleDateString('en-IN',{day:'2-digit',month:'short'});
                        return a.doctor===form.doctor && a.date===aDate && a.status!=='Cancelled';
                      })
                      .map(a => a.time);
                    return (
                      <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:6}}>
                        {slots.map(slot => {
                          const [h,m]  = slot.split(':').map(Number);
                          const isPast = isToday && (h < nowHour || (h === nowHour && m <= nowMin));
                          const isNow  = isToday && h === nowHour;
                          const isBook = bookedSlots.includes(slot);
                          const isSel  = form.time === slot;
                          const disabled = isPast || isBook;
                          return (
                            <button key={slot} disabled={disabled} onClick={()=>!disabled&&setForm(p=>({...p,time:slot}))}
                              style={{
                                padding:'7px 4px', borderRadius:7, fontSize:11.5, fontWeight:600,
                                cursor:disabled?'not-allowed':'pointer', fontFamily:'inherit',
                                border: isSel ? '2px solid #1a63c8' : '1px solid #dde2eb',
                                background: isSel ? '#1a63c8' : isBook ? '#f3f4f6' : isPast ? '#f9fafb' : isNow ? '#fffbeb' : '#fff',
                                color:  isSel ? '#fff' : isBook ? '#9ca3af' : isPast ? '#d1d5db' : isNow ? '#92400e' : '#374151',
                                opacity: disabled ? 0.6 : 1,
                                textDecoration: isPast ? 'line-through' : 'none',
                                position:'relative'
                              }}>
                              {slot}
                              {isNow && !isPast && !isBook && !isSel && <span style={{position:'absolute',top:1,right:2,fontSize:7,color:'#92400e'}}>now</span>}
                              {isBook && <span style={{display:'block',fontSize:9,color:'#9ca3af',marginTop:1}}>booked</span>}
                            </button>
                          );
                        })}
                      </div>
                    );
                  })()
              }
              {form.time && <div style={{marginTop:8,fontSize:12,color:'#1a63c8',fontWeight:600}}>✓ Selected: {form.time}</div>}
            </div>
          </div>
          <div style={{display:'flex',gap:8,marginTop:12}}>
            <Btn primary onClick={handleAdd}>{role === 'Patient' ? 'Request Appointment' : 'Book Appointment'}</Btn>
            <Btn onClick={() => setShowAdd(false)}>Cancel</Btn>
          </div>
        </Modal>
      )}
    </div>
  );
}

function RecordsPage({ state, setState, toast, addAudit, currentUser }) {
  const isPatient = currentUser?.role === 'Patient';
  const [showAdd, setShowAdd] = useState(false);
  const [viewId, setViewId] = useState(null);
  const [form, setForm] = useState({ patient:"", age:"", doctor:"", diagnosis:"", prescription:"", notes:"" });
  const f = k => v => setForm(p=>({...p,[k]:v}));
  const viewR = viewId ? state.records.find(r=>r.id===viewId) : null;

  const handleAdd = () => {
    if(!form.diagnosis){toast("Diagnosis required");return;}
    const nums = state.records.map(r=>parseInt(r.id.replace(/\D/g,""))).filter(n=>!isNaN(n));
    const id = "R-"+(Math.max(0,...nums)+1);
    setState(s=>({...s,records:[...s.records,{id,patient:form.patient||"Unknown",age:parseInt(form.age)||0,doctor:form.doctor||"—",diagnosis:form.diagnosis,prescription:form.prescription,notes:form.notes,date:today()}]}));
    addAudit(`EMR ${id} created`,"info");
    setShowAdd(false); setForm({patient:"",age:"",doctor:"",diagnosis:"",prescription:"",notes:""});
    toast(`✓ Record ${id} saved!`);
  };

  return (
    <div>
      {(!currentUser || currentUser.role !== 'Patient') && (<div style={{display:"flex",justifyContent:"flex-end",marginBottom:12}}><Btn primary onClick={()=>setShowAdd(true)}>+ New Record</Btn></div>)}
      <Card>
        <Table heads={["ID","Patient","Age","Diagnosis","Doctor","Date","Action"]}
          rows={state.records.map(r=>[r.id,r.patient,r.age,r.diagnosis,r.doctor,r.date,<Btn small onClick={()=>setViewId(r.id)}>View EMR</Btn>])} />
      </Card>
      {showAdd && (
        <Modal title="New Medical Record" onClose={()=>setShowAdd(false)} wide={520}>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
            <Input label="Patient Name" value={form.patient} onChange={f("patient")} />
            <Input label="Age" type="number" value={form.age} onChange={f("age")} />
            <Input label="Doctor" value={form.doctor} onChange={f("doctor")} />
          </div>
          <Input label="Diagnosis *" value={form.diagnosis} onChange={f("diagnosis")} />
          <Input label="Prescription" value={form.prescription} onChange={f("prescription")} />
          <Input label="Notes" value={form.notes} onChange={f("notes")} />
          <div style={{display:"flex",gap:8,marginTop:8}}><Btn primary onClick={handleAdd}>Save Record</Btn><Btn onClick={()=>setShowAdd(false)}>Cancel</Btn></div>
        </Modal>
      )}
      {viewR && (
        <Modal title={`Medical Record — ${viewR.id}`} onClose={()=>setViewId(null)} wide={500}>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12,fontSize:13}}>
            {[["Patient",viewR.patient],["Age",viewR.age],["Doctor",viewR.doctor],["Date",viewR.date]].map(([k,v])=>
              <div key={k}><div style={{fontSize:10,color:"#6b7280",fontWeight:700,textTransform:"uppercase",marginBottom:2}}>{k}</div><div>{v}</div></div>)}
          </div>
          <div style={{marginTop:12}}><div style={{fontSize:10,color:"#6b7280",fontWeight:700,textTransform:"uppercase",marginBottom:4}}>Diagnosis</div><div style={{fontWeight:600,fontSize:13}}>{viewR.diagnosis}</div></div>
          <div style={{marginTop:10}}><div style={{fontSize:10,color:"#6b7280",fontWeight:700,textTransform:"uppercase",marginBottom:4}}>Prescription</div><div style={{fontSize:13}}>{viewR.prescription||"—"}</div></div>
          {viewR.notes&&<div style={{marginTop:10}}><div style={{fontSize:10,color:"#6b7280",fontWeight:700,textTransform:"uppercase",marginBottom:4}}>Notes</div><div style={{fontSize:13}}>{viewR.notes}</div></div>}
          <div style={{marginTop:16,textAlign:"right"}}><Btn onClick={()=>setViewId(null)}>Close</Btn></div>
        </Modal>
      )}
    </div>
  );
}

function LabPage({ state, setState, toast, addAudit, currentUser }) {
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ patient:"", test:"CBC", orderedBy:"" });
  const f = k => v => setForm(p=>({...p,[k]:v}));
  const tests = ["CBC","ECG","MRI Brain","X-Ray","Urine Culture","HbA1c","Lipid Panel","CT Scan","Blood Sugar"];

  const handleAdd = () => {
    if(!form.patient){toast("Patient required");return;}
    const nums = state.labReports.map(l=>parseInt(l.id.replace(/\D/g,""))).filter(n=>!isNaN(n));
    const id = "L-"+(Math.max(0,...nums)+1);
    setState(s=>({...s,labReports:[...s.labReports,{id,patient:form.patient,test:form.test,orderedBy:form.orderedBy||"—",date:today().slice(0,6),status:"Pending"}]}));
    addAudit(`Lab ${id} ordered — ${form.test}`,"warning");
    setShowAdd(false); setForm({patient:"",test:"CBC",orderedBy:""});
    toast(`✓ Lab test ${id} ordered!`);
  };

  return (
    <div>
      {(!currentUser || currentUser.role !== 'Patient') && (<div style={{display:"flex",justifyContent:"flex-end",marginBottom:12}}><Btn primary onClick={()=>setShowAdd(true)}>+ Order Lab Test</Btn></div>)}
      <Card>
        <Table heads={["ID","Patient","Test","Ordered By","Date","Status"]}
          rows={state.labReports.map(l=>[l.id,l.patient,l.test,l.orderedBy,l.date,<Badge s={l.status}/>])} />
      </Card>
      {showAdd && (
        <Modal title="Order Lab Test" onClose={()=>setShowAdd(false)}>
          <Input label="Patient Name *" value={form.patient} onChange={f("patient")} />
          <Sel label="Test Type" value={form.test} onChange={f("test")} options={tests} />
          <Input label="Ordered By" value={form.orderedBy} onChange={f("orderedBy")} placeholder="Dr. Mehta" />
          <div style={{display:"flex",gap:8,marginTop:8}}><Btn primary onClick={handleAdd}>Order</Btn><Btn onClick={()=>setShowAdd(false)}>Cancel</Btn></div>
        </Modal>
      )}
    </div>
  );
}

function PharmacyPage({ state, setState, toast, addAudit, currentUser }) {
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ name:"", cat:"Analgesic", mfg:"", stock:"", reorder:"100", price:"", expiry:"" });
  const f = k => v => setForm(p=>({...p,[k]:v}));
  const getStatus = m => m.stock <= 0 ? "Out of Stock" : m.stock < m.reorder ? "Low Stock" : "In Stock";

  const handleAdd = () => {
    if(!form.name){toast("Name required");return;}
    setState(s=>({...s,pharmacy:[...s.pharmacy,{name:form.name,cat:form.cat,mfg:form.mfg,stock:parseInt(form.stock)||0,reorder:parseInt(form.reorder)||100,price:parseFloat(form.price)||0,expiry:form.expiry||"—"}]}));
    addAudit(`${form.name} added to pharmacy`,"success");
    setShowAdd(false); setForm({name:"",cat:"Analgesic",mfg:"",stock:"",reorder:"100",price:"",expiry:""});
    toast("✓ Medicine added!");
  };
  const dispense = i => {
    setState(s=>({...s,pharmacy:s.pharmacy.map((m,idx)=>idx===i?{...m,stock:Math.max(0,m.stock-1)}:m)}));
    toast("✓ 1 unit dispensed");
  };

  return (
    <div>
      {(!currentUser || currentUser.role !== 'Patient') && (<div style={{display:"flex",justifyContent:"flex-end",marginBottom:12}}><Btn primary onClick={()=>setShowAdd(true)}>+ Add Medicine</Btn></div>)}
      <Card>
        <Table heads={["Name","Category","Manufacturer","Stock","Reorder","Expiry","Price","Status","Action"]}
          rows={state.pharmacy.map((m,i)=>[m.name,m.cat,m.mfg,<strong>{m.stock}</strong>,m.reorder,m.expiry,rupee(m.price),<Badge s={getStatus(m)}/>,
            (!currentUser||currentUser.role!=='Patient') ? (m.stock<m.reorder?<Btn small danger onClick={()=>toast("Reorder sent!")}>Reorder</Btn>:<Btn small onClick={()=>dispense(i)}>Dispense</Btn>) : <span style={{color:'#9ca3af',fontSize:11}}>View only</span>])} />
      </Card>
      {showAdd && (
        <Modal title="Add Medicine" onClose={()=>setShowAdd(false)} wide={480}>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
            <div style={{gridColumn:"1/-1"}}><Input label="Medicine Name *" value={form.name} onChange={f("name")} /></div>
            <Sel label="Category" value={form.cat} onChange={f("cat")} options={["Analgesic","Antibiotic","Anti-Diabetic","Antiemetic","Lipid-Lowering","Other"]} />
            <Input label="Manufacturer" value={form.mfg} onChange={f("mfg")} />
            <Input label="Stock (units)" type="number" value={form.stock} onChange={f("stock")} />
            <Input label="Price (₹)" type="number" value={form.price} onChange={f("price")} />
          </div>
          <div style={{display:"flex",gap:8,marginTop:8}}><Btn primary onClick={handleAdd}>Add</Btn><Btn onClick={()=>setShowAdd(false)}>Cancel</Btn></div>
        </Modal>
      )}
    </div>
  );
}

function SurgeryPage({ state, setState, toast, addAudit, currentUser }) {
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ patient:"", procedure:"", surgeon:"Dr. Rajesh Mehta", ot:"OT-1", date:"", time:"" });
  const f = k => v => setForm(p=>({...p,[k]:v}));

  const handleAdd = () => {
    if(!form.procedure){toast("Procedure required");return;}
    const nums = state.surgeries.map(s=>parseInt(s.id.replace(/\D/g,""))).filter(n=>!isNaN(n));
    const id = "SG-"+String(Math.max(0,...nums)+1).padStart(3,"0");
    const ds = form.date ? new Date(form.date).toLocaleDateString("en-IN",{day:"2-digit",month:"short"})+(form.time?", "+form.time:"") : today().slice(0,6);
    setState(s=>({...s,surgeries:[...s.surgeries,{id,patient:form.patient||"—",procedure:form.procedure,surgeon:form.surgeon,ot:form.ot,datetime:ds,status:"Scheduled"}]}));
    addAudit(`Surgery ${id} scheduled`,"info");
    setShowAdd(false); toast(`✓ Surgery ${id} scheduled!`);
  };

  return (
    <div>
      {(!currentUser || currentUser.role !== 'Patient') && (<div style={{display:"flex",justifyContent:"flex-end",marginBottom:12}}><Btn primary onClick={()=>setShowAdd(true)}>+ Schedule Surgery</Btn></div>)}
      <Card>
        <Table heads={["ID","Patient","Procedure","Surgeon","OT","Date/Time","Status"]}
          rows={state.surgeries.map(s=>[s.id,s.patient,s.procedure,s.surgeon,s.ot,s.datetime,<Badge s={s.status}/>])} />
      </Card>
      {showAdd && (
        <Modal title="Schedule Surgery" onClose={()=>setShowAdd(false)}>
          <Input label="Patient Name" value={form.patient} onChange={f("patient")} />
          <Input label="Procedure *" value={form.procedure} onChange={f("procedure")} placeholder="e.g. Appendectomy" />
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
            <Sel label="Surgeon" value={form.surgeon} onChange={f("surgeon")} options={state.doctors.map(d=>d.name)} />
            <Sel label="OT Room" value={form.ot} onChange={f("ot")} options={["OT-1","OT-2","OT-3","OT-4"]} />
            <Input label="Date" type="date" value={form.date} onChange={f("date")} />
            <Input label="Time" type="time" value={form.time} onChange={f("time")} />
          </div>
          <div style={{display:"flex",gap:8,marginTop:8}}><Btn primary onClick={handleAdd}>Schedule</Btn><Btn onClick={()=>setShowAdd(false)}>Cancel</Btn></div>
        </Modal>
      )}
    </div>
  );
}

function WardsPage({ state, setState, toast, currentUser }) {
  const [showAssign, setShowAssign] = useState(false);
  const [form, setForm] = useState({ wardName:"", patient:"", admType:"Regular" });
  const f = k => v => setForm(p=>({...p,[k]:v}));
  const totBeds = state.wards.reduce((s,w)=>s+w.beds,0);
  const totOcc  = state.wards.reduce((s,w)=>s+w.occupied,0);

  const handleAssign = () => {
    if(!form.wardName||!form.patient){toast("Select ward and enter patient");return;}
    setState(s=>({...s,wards:s.wards.map(w=>w.name===form.wardName&&w.occupied<w.beds?{...w,occupied:w.occupied+1}:w)}));
    setShowAssign(false); toast(`✓ Bed assigned in ${form.wardName} to ${form.patient}`);
  };

  return (
    <div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:12,marginBottom:12}}>
        <StatCard label="Total Beds" value={totBeds} color="#1a63c8"/>
        <StatCard label="Occupied" value={totOcc} color="#92400e"/>
        <StatCard label="Available" value={totBeds-totOcc} color="#166534"/>
      </div>
      {(!currentUser || currentUser.role !== 'Patient') && (<div style={{display:"flex",justifyContent:"flex-end",marginBottom:12}}><Btn primary onClick={()=>setShowAssign(true)}>+ Assign Bed</Btn></div>)}
      <Card>
        <Table heads={["Ward","Type","Beds","Occupied","Available","Rate/Day","Occupancy","Status"]}
          rows={state.wards.map(w=>{
            const pct=Math.round((w.occupied/w.beds)*100);
            const st=pct>=90?"Full":pct>=70?"High":"Available";
            return [w.name,w.type,w.beds,w.occupied,w.beds-w.occupied,rupee(w.rate),
              <div style={{width:80}}><ProgressBar pct={pct} color={pct>=90?"#9b1c1c":pct>=70?"#92400e":"#166534"}/><div style={{fontSize:10,color:"#6b7280",marginTop:2}}>{pct}%</div></div>,
              <Badge s={st}/>];
          })} />
      </Card>
      {showAssign && (
        <Modal title="Assign Bed" onClose={()=>setShowAssign(false)}>
          <Sel label="Ward *" value={form.wardName} onChange={f("wardName")} options={["—select—",...state.wards.filter(w=>w.occupied<w.beds).map(w=>w.name)]} />
          <Input label="Patient Name *" value={form.patient} onChange={f("patient")} placeholder="Patient name or ID" />
          <Sel label="Admission Type" value={form.admType} onChange={f("admType")} options={["Regular","Emergency","Post-Op","ICU Transfer"]} />
          <div style={{display:"flex",gap:8,marginTop:8}}><Btn primary onClick={handleAssign}>Assign Bed</Btn><Btn onClick={()=>setShowAssign(false)}>Cancel</Btn></div>
        </Modal>
      )}
    </div>
  );
}

function BloodBankPage({ state, setState, toast, addAudit, addNotif }) {
  const [showDonor, setShowDonor] = useState(false);
  const [showReq, setShowReq]     = useState(false);
  const [viewDonor, setViewDonor] = useState(null);
  const [form,    setForm]   = useState({ name:"", phone:"", altPhone:"", bg:"A+", units:"1", age:"", email:"", address:"" });
  const [rForm,   setRForm]  = useState({ patient:"", bg:"A+", units:"1", priority:"Normal", contactPhone:"" });
  const rf = k => v => setForm(p=>({...p,[k]:v}));
  const rrf = k => v => setRForm(p=>({...p,[k]:v}));
  const order = ["A+","B+","O+","AB+","A-","B-","O-","AB-"];

  const handleDonor = () => {
    if(!form.name){toast("Donor name required");return;}
    if(!form.phone){toast("Phone required");return;}
    const u = parseInt(form.units)||1;
    setState(s=>({...s,donors:[{name:form.name,phone:form.phone,altPhone:form.altPhone,bg:form.bg,units:u,date:today(),status:"Testing",age:form.age,email:form.email,address:form.address},...s.donors],bloodStock:{...s.bloodStock,[form.bg]:(s.bloodStock[form.bg]||0)+u}}));
    addAudit(`Blood donation by ${form.name} (${form.bg}, ${u}u)`,"success");
    addNotif(`Donor ${form.name} — +${u}u ${form.bg}`,"success","Blood Bank");
    setShowDonor(false); setForm({name:"",phone:"",altPhone:"",bg:"A+",units:"1",age:"",email:"",address:""});
    toast(`✓ Donor registered! +${u} units of ${form.bg}`);
  };
  const handleReq = () => {
    const u = parseInt(rForm.units)||1;
    const cur = state.bloodStock[rForm.bg]||0;
    if(!rForm.patient){toast("Enter patient name");return;}
    if(cur<u){toast(`⚠ Only ${cur} units of ${rForm.bg} available!`);return;}
    setState(s=>({...s,bloodStock:{...s.bloodStock,[rForm.bg]:s.bloodStock[rForm.bg]-u}}));
    addAudit(`Blood issued: ${u}u ${rForm.bg} → ${rForm.patient}`,"info");
    if(cur-u<6) addNotif(`🩸 ${rForm.bg} critically low — ${cur-u}u left`,"danger","Blood Bank");
    setShowReq(false); toast(`✓ ${u}u of ${rForm.bg} issued to ${rForm.patient}`);
  };

  return (
    <div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:10,marginBottom:14}}>
        {order.map(bg=>{
          const u=state.bloodStock[bg]||0,low=u<12,crit=u<6;
          return(
            <div key={bg} style={{background:"#fff",border:`1px solid ${crit?"#fca5a5":low?"#fde68a":"#e5e7eb"}`,borderRadius:10,padding:"12px 8px",textAlign:"center"}}>
              <div style={{fontSize:20,fontWeight:800,color:crit?"#9b1c1c":low?"#92400e":"#1a1d24"}}>{bg}</div>
              <div style={{fontSize:11,color:crit?"#9b1c1c":low?"#92400e":"#6b7280",marginTop:4}}>{u} units{crit?" 🚨":low?" ⚠":""}</div>
              <ProgressBar pct={Math.min(100,Math.round((u/50)*100))} color={crit?"#9b1c1c":low?"#92400e":"#166534"}/>
            </div>
          );
        })}
      </div>
      <div style={{display:"flex",gap:8,justifyContent:"flex-end",marginBottom:12}}>
        <Btn onClick={()=>setShowReq(true)}>🩸 Request Blood</Btn>
        <Btn primary onClick={()=>setShowDonor(true)}>+ Register Donor</Btn>
      </div>
      <Card>
        <div style={{fontWeight:700,fontSize:13,marginBottom:10}}>Donor Records ({state.donors.length})</div>
        <Table heads={["Donor","📞 Primary Phone","Alt Phone","Blood Group","Units","Date","Status","Action"]}
          rows={state.donors.map((d,i)=>[d.name,d.phone||"—",d.altPhone||"—",<strong style={{color:"#9b1c1c"}}>{d.bg}</strong>,d.units,d.date,<Badge s={d.status}/>,<Btn small onClick={()=>setViewDonor(d)}>View</Btn>])} />
      </Card>

      {showDonor && (
        <Modal title="Register Blood Donor" onClose={()=>setShowDonor(false)} wide={480}>
          <Input label="Full Name *" value={form.name} onChange={rf("name")} placeholder="Aditya Sharma" />
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
            <Input label="Primary Phone *" value={form.phone} onChange={rf("phone")} placeholder="+91 98765 43210" />
            <Input label="Alternate Phone" value={form.altPhone} onChange={rf("altPhone")} placeholder="+91 87654 32109" />
            <Sel label="Blood Group *" value={form.bg} onChange={rf("bg")} options={order} />
            <Input label="Units" type="number" value={form.units} onChange={rf("units")} />
            <Input label="Age" type="number" value={form.age} onChange={rf("age")} />
            <Input label="Email" value={form.email} onChange={rf("email")} />
          </div>
          <Input label="Address" value={form.address} onChange={rf("address")} />
          <div style={{display:"flex",gap:8,marginTop:8}}><Btn primary onClick={handleDonor}>Register</Btn><Btn onClick={()=>setShowDonor(false)}>Cancel</Btn></div>
        </Modal>
      )}

      {showReq && (
        <Modal title="Request / Issue Blood" onClose={()=>setShowReq(false)}>
          <Input label="Patient Name *" value={rForm.patient} onChange={rrf("patient")} />
          <Input label="Contact Phone" value={rForm.contactPhone} onChange={rrf("contactPhone")} />
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
            <Sel label="Blood Group" value={rForm.bg} onChange={rrf("bg")} options={order} />
            <Input label="Units" type="number" value={rForm.units} onChange={rrf("units")} />
            <Sel label="Priority" value={rForm.priority} onChange={rrf("priority")} options={["Normal","Urgent","Critical"]} />
          </div>
          <div style={{padding:"10px 14px",borderRadius:8,background:(state.bloodStock[rForm.bg]||0)<parseInt(rForm.units||"1")?"#fef2f2":"#f0fdf4",marginBottom:10,fontSize:12.5,fontWeight:600,color:(state.bloodStock[rForm.bg]||0)<parseInt(rForm.units||"1")?"#9b1c1c":"#166534"}}>
            Available: {state.bloodStock[rForm.bg]||0} units of {rForm.bg}
          </div>
          <div style={{display:"flex",gap:8}}><Btn primary onClick={handleReq}>Issue Blood</Btn><Btn onClick={()=>setShowReq(false)}>Cancel</Btn></div>
        </Modal>
      )}

      {viewDonor && (
        <Modal title="Donor Details" onClose={()=>setViewDonor(null)}>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12,fontSize:13}}>
            {[["Name",viewDonor.name],["Blood Group",<strong style={{color:"#9b1c1c",fontSize:16}}>{viewDonor.bg}</strong>],["Primary Phone",viewDonor.phone||"—"],["Alt Phone",viewDonor.altPhone||"—"],["Age",viewDonor.age||"—"],["Email",viewDonor.email||"—"],["Units Donated",viewDonor.units],["Date",viewDonor.date],["Status",<Badge s={viewDonor.status}/>]].map(([k,v])=>
              <div key={k}><div style={{fontSize:10,color:"#6b7280",fontWeight:700,textTransform:"uppercase",marginBottom:2}}>{k}</div><div style={{fontWeight:500}}>{v}</div></div>)}
            {viewDonor.address&&<div style={{gridColumn:"1/-1"}}><div style={{fontSize:10,color:"#6b7280",fontWeight:700,textTransform:"uppercase",marginBottom:2}}>Address</div><div>{viewDonor.address}</div></div>}
          </div>
          <div style={{marginTop:16,textAlign:"right"}}><Btn onClick={()=>setViewDonor(null)}>Close</Btn></div>
        </Modal>
      )}
    </div>
  );
}

function StaffPage({ state, setState, toast, addAudit, currentUser }) {
  const [showAdd, setShowAdd] = useState(false);
  const [editId, setEditId]   = useState(null);
  const [form, setForm] = useState({ name:"", role:"Nurse", dept:"OPD", shift:"Morning", salary:"", phone:"", status:"Active" });
  const f = k => v => setForm(p=>({...p,[k]:v}));

  const handleAdd = () => {
    if(!form.name){toast("Name required");return;}
    const nums = state.staff.map(s=>parseInt(s.id.replace(/\D/g,""))).filter(n=>!isNaN(n));
    const id = "ST-"+String(Math.max(0,...nums)+1).padStart(3,"0");
    setState(s=>({...s,staff:[...s.staff,{...form,id,salary:parseInt(form.salary)||0}]}));
    addAudit(`Staff ${id} registered — ${form.role}`,"success");
    setShowAdd(false); toast(`✓ ${form.name} added!`);
  };
  const handleEdit = () => {
    setState(s=>({...s,staff:s.staff.map(x=>x.id===editId?{...x,...form,salary:parseInt(form.salary)||x.salary}:x)}));
    addAudit(`Staff ${editId} updated`,"info");
    setEditId(null); toast("✓ Staff updated");
  };
  const openEdit = id => { const s=state.staff.find(x=>x.id===id); setForm({name:s.name,role:s.role,dept:s.dept,shift:s.shift,salary:String(s.salary),phone:s.phone,status:s.status}); setEditId(id); };

  return (
    <div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:12,marginBottom:12}}>
        <StatCard label="Total Staff" value={state.staff.length} color="#1a63c8"/>
        <StatCard label="Active" value={state.staff.filter(s=>s.status==="Active").length} color="#166534"/>
        <StatCard label="On Leave" value={state.staff.filter(s=>s.status==="On Leave").length} color="#92400e"/>
      </div>
      {(!currentUser || currentUser.role !== 'Patient') && (<div style={{display:"flex",justifyContent:"flex-end",marginBottom:12}}><Btn primary onClick={()=>setShowAdd(true)}>+ Add Staff</Btn></div>)}
      <Card>
        <Table
          heads={['Patient','Doctor','Staff'].includes(currentUser?.role)
            ? ['ID','Name','Role','Dept','Shift','Phone','Status','Action']
            : ['ID','Name','Role','Dept','Shift','Salary','Phone','Status','Action']}
          rows={state.staff.map(s=>['Patient','Doctor','Staff'].includes(currentUser?.role)
            ? [s.id,s.name,s.role,s.dept,s.shift,s.phone,<Badge s={s.status}/>,
               currentUser?.role==='Patient'?<span style={{color:'#9ca3af',fontSize:11}}>—</span>:<Btn small onClick={()=>openEdit(s.id)}>Edit</Btn>]
            : [s.id,s.name,s.role,s.dept,s.shift,rupee(s.salary),s.phone,<Badge s={s.status}/>,
               <Btn small onClick={()=>openEdit(s.id)}>Edit</Btn>])} />
      </Card>

      {/* Staff Attendance */}
      <Card>
        <div style={{fontWeight:700,fontSize:13,marginBottom:4}}>Staff Attendance — Today</div>
        <div style={{fontSize:11.5,color:'#6b7280',marginBottom:12}}>{new Date().toLocaleDateString('en-IN',{weekday:'long',day:'numeric',month:'long',year:'numeric'})}</div>
        <Table heads={['ID','Name','Role','Department','Shift','Status','Attendance','Action']}
          rows={state.staff.map((s,i)=>{
            const present = s.status==='Active';
            const onLeave = s.status==='On Leave';
            return [
              s.id, s.name, s.role, s.dept, s.shift,
              <Badge s={s.status}/>,
              present ? <span style={{color:'#166534',fontWeight:600}}>✓ Present</span>
                : onLeave ? <span style={{color:'#92400e',fontWeight:600}}>✗ On Leave</span>
                : <span style={{color:'#9b1c1c',fontWeight:600}}>✗ Absent</span>,
              (currentUser?.role==='Patient'||currentUser?.role==='Staff')
                ? <span style={{color:'#9ca3af',fontSize:11}}>—</span>
                : <div style={{display:'flex',gap:4}}>
                    <Btn small onClick={()=>{setState(s2=>({...s2,staff:s2.staff.map((x,j)=>j===i?{...x,status:'Active'}:x)}));toast('✓ Marked Present');}}>Present</Btn>
                    <Btn small danger onClick={()=>{setState(s2=>({...s2,staff:s2.staff.map((x,j)=>j===i?{...x,status:'On Leave'}:x)}));toast('✓ Marked Absent');}}>Absent</Btn>
                  </div>
            ];
          })} />
      </Card>
      {(showAdd||editId) && (
        <Modal title={editId?`Edit Staff — ${editId}`:"Add New Staff"} onClose={()=>{setShowAdd(false);setEditId(null);}}>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
            <div style={{gridColumn:"1/-1"}}><Input label="Full Name *" value={form.name} onChange={f("name")} /></div>
            <Sel label="Role" value={form.role} onChange={f("role")} options={["Head Nurse","Nurse","Lab Technician","Pharmacist","Receptionist","Ambulance Driver","Housekeeping"]} />
            <Sel label="Department" value={form.dept} onChange={f("dept")} options={["ICU","OPD","Emergency","Pharmacy","Pathology","Ward A","Ward B","General"]} />
            <Sel label="Shift" value={form.shift} onChange={f("shift")} options={["Morning","Evening","Night"]} />
            <Input label="Phone" value={form.phone} onChange={f("phone")} />
            {currentUser?.role==='Admin' && <Input label="Salary (₹)" type="number" value={form.salary} onChange={f("salary")} />}
            {currentUser?.role==='Admin' && <Sel label="Status" value={form.status} onChange={f("status")} options={["Active","On Leave","Off Duty"]} />}
          </div>
          <div style={{display:"flex",gap:8,marginTop:8}}><Btn primary onClick={editId?handleEdit:handleAdd}>{editId?"Save":"Add Staff"}</Btn><Btn onClick={()=>{setShowAdd(false);setEditId(null);}}>Cancel</Btn></div>
        </Modal>
      )}
    </div>
  );
}

function BillingPage({ state, setState, toast, addAudit, currentUser }) {
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ patient:"", services:"", total:"", insurance:"", mode:"Cash" });
  const f = k => v => setForm(p=>({...p,[k]:v}));
  const totBilled  = state.billing.reduce((s,b)=>s+b.total,0);
  const paidAmt    = state.billing.filter(b=>b.status==="Paid").reduce((s,b)=>s+b.total,0);
  const pendingDue = state.billing.filter(b=>b.status!=="Paid").reduce((s,b)=>s+Math.max(0,b.total-b.insurance),0);

  const handleAdd = () => {
    if(!form.services||!form.total){toast("Fill services and amount");return;}
    const nums = state.billing.map(b=>parseInt(b.inv.replace(/\D/g,""))).filter(n=>!isNaN(n));
    const inv = "INV-"+(Math.max(0,...nums)+1);
    const tot=parseFloat(form.total)||0, ins=parseFloat(form.insurance)||0;
    const status = tot-ins<=0?"Paid":ins>0?"Partial":"Unpaid";
    setState(s=>({...s,billing:[...s.billing,{inv,patient:form.patient||"Unknown",services:form.services,total:tot,insurance:ins,mode:form.mode,status}]}));
    addAudit(`Invoice ${inv} generated`,"success");
    setShowAdd(false); setForm({patient:"",services:"",total:"",insurance:"",mode:"Cash"});
    toast(`✓ Invoice ${inv} generated!`);
  };

  return (
    <div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:12,marginBottom:12}}>
        <StatCard label="Total Billed" value={rupee(totBilled)} color="#1a63c8"/>
        <StatCard label="Amount Received" value={rupee(paidAmt)} color="#166534"/>
        <StatCard label="Pending Dues" value={rupee(pendingDue)} color="#9b1c1c"/>
      </div>
      {(!currentUser || currentUser.role !== 'Patient') && (<div style={{display:"flex",justifyContent:"flex-end",marginBottom:12}}><Btn primary onClick={()=>setShowAdd(true)}>+ New Invoice</Btn></div>)}
      <Card>
        <Table heads={["Invoice","Patient","Services","Total","Insurance","Balance","Mode","Status"]}
          rows={state.billing.map(b=>{
            const bal=Math.max(0,b.total-b.insurance);
            return [b.inv,b.patient,b.services,rupee(b.total),b.insurance>0?rupee(b.insurance):"—",<span style={{color:bal>0?"#9b1c1c":"#166534",fontWeight:600}}>{rupee(bal)}</span>,b.mode,<Badge s={b.status}/>];
          })} />
      </Card>
      {showAdd && (
        <Modal title="Generate Invoice" onClose={()=>setShowAdd(false)}>
          <Input label="Patient Name" value={form.patient} onChange={f("patient")} />
          <Input label="Services *" value={form.services} onChange={f("services")} placeholder="Surgery + Bed + Meds" />
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
            <Input label="Total (₹) *" type="number" value={form.total} onChange={f("total")} />
            <Input label="Insurance (₹)" type="number" value={form.insurance} onChange={f("insurance")} />
            <Sel label="Payment Mode" value={form.mode} onChange={f("mode")} options={["Cash","UPI","Card","Insurance","Pending"]} />
          </div>
          <div style={{display:"flex",gap:8,marginTop:8}}><Btn primary onClick={handleAdd}>Generate</Btn><Btn onClick={()=>setShowAdd(false)}>Cancel</Btn></div>
        </Modal>
      )}
    </div>
  );
}

function InventoryPage({ state, setState, toast, addAudit, currentUser }) {
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ name:"", cat:"PPE", unit:"Pcs", qty:"", reorder:"100" });
  const f = k => v => setForm(p=>({...p,[k]:v}));

  const handleAdd = () => {
    if(!form.name){toast("Item name required");return;}
    setState(s=>({...s,inventory:[...s.inventory,{name:form.name,cat:form.cat,unit:form.unit,qty:parseInt(form.qty)||0,reorder:parseInt(form.reorder)||100}]}));
    addAudit(`${form.name} added to inventory`,"success");
    setShowAdd(false); setForm({name:"",cat:"PPE",unit:"Pcs",qty:"",reorder:"100"});
    toast("✓ Item added!");
  };

  return (
    <div>
      {(!currentUser || currentUser.role !== 'Patient') && (<div style={{display:"flex",justifyContent:"flex-end",marginBottom:12}}><Btn primary onClick={()=>setShowAdd(true)}>+ Add Item</Btn></div>)}
      <Card>
        <Table heads={["Name","Category","Quantity","Unit","Reorder Level","Status","Action"]}
          rows={state.inventory.map((item,i)=>{
            const st=item.qty<item.reorder?"Low":"OK";
            return [item.name,item.cat,<strong>{item.qty.toLocaleString()}</strong>,item.unit,item.reorder,<Badge s={st}/>,currentUser?.role==='Patient'?<span style={{color:'#9ca3af',fontSize:11}}>—</span>:<Btn small onClick={()=>toast(`Stock updated for ${item.name}`)}>Update</Btn>];
          })} />
      </Card>
      {showAdd && (
        <Modal title="Add Inventory Item" onClose={()=>setShowAdd(false)}>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
            <div style={{gridColumn:"1/-1"}}><Input label="Item Name *" value={form.name} onChange={f("name")} /></div>
            <Sel label="Category" value={form.cat} onChange={f("cat")} options={["PPE","Consumable","Equipment"]} />
            <Sel label="Unit" value={form.unit} onChange={f("unit")} options={["Pcs","Pairs","Units","Cylinders","Boxes"]} />
            <Input label="Quantity" type="number" value={form.qty} onChange={f("qty")} />
            <Input label="Reorder Level" type="number" value={form.reorder} onChange={f("reorder")} />
          </div>
          <div style={{display:"flex",gap:8,marginTop:8}}><Btn primary onClick={handleAdd}>Add</Btn><Btn onClick={()=>setShowAdd(false)}>Cancel</Btn></div>
        </Modal>
      )}
    </div>
  );
}

function AmbulancePage({ state, setState, toast, addAudit, addNotif, currentUser }) {
  const [showDispatch, setShowDispatch] = useState(false);
  const [form, setForm] = useState({ ambId:"", patient:"", loc:"" });
  const f = k => v => setForm(p=>({...p,[k]:v}));
  const avail = state.ambulance.filter(a=>a.status==="Available");

  const handleDispatch = () => {
    if(!form.ambId||!form.loc){toast("Select ambulance and enter location");return;}
    setState(s=>({...s,ambulance:s.ambulance.map(a=>a.id===form.ambId?{...a,status:"Dispatched",location:form.loc}:a)}));
    addAudit(`${form.ambId} dispatched to ${form.loc}`,"danger");
    addNotif(`🚑 ${form.ambId} dispatched to ${form.loc}`,"danger","Ambulance");
    setShowDispatch(false); toast(`✓ ${form.ambId} dispatched!`);
  };

  return (
    <div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:12,marginBottom:12}}>
        <StatCard label="Total Fleet" value={state.ambulance.length} color="#1a63c8"/>
        <StatCard label="Available" value={avail.length} color="#166534"/>
        <StatCard label="Dispatched" value={state.ambulance.length-avail.length} color="#92400e"/>
      </div>
      {(!currentUser || currentUser.role !== 'Patient') && (<div style={{display:"flex",justifyContent:"flex-end",marginBottom:12}}><Btn primary onClick={()=>{setShowDispatch(true);setForm({ambId:avail[0]?.id||"",patient:"",loc:""})}}>+ Dispatch</Btn></div>)}
      <Card>
        <Table heads={["ID","Type","Driver","Phone","Location","Status","Action"]}
          rows={state.ambulance.map(a=>[a.id,a.type,a.driver,a.phone,a.location,<Badge s={a.status}/>,
            a.status==="Available"
              ? (currentUser?.role==='Patient' ? <span style={{color:'#166534',fontSize:11,fontWeight:600}}>Available</span> : <Btn small primary onClick={()=>{setShowDispatch(true);setForm({ambId:a.id,patient:'',loc:''})}}>Dispatch</Btn>)
              : (currentUser?.role==='Patient' ? <span style={{color:'#1a63c8',fontSize:11,fontWeight:600}}>Dispatched</span> : <Btn small onClick={()=>toast(`Tracking ${a.id}`)}>Track</Btn>)])} />
      </Card>
      {showDispatch && (
        <Modal title="Dispatch Ambulance" onClose={()=>setShowDispatch(false)}>
          <Sel label="Ambulance *" value={form.ambId} onChange={f("ambId")} options={avail.map(a=>`${a.id} — ${a.type} (${a.driver})`)} />
          <Input label="Destination *" value={form.loc} onChange={f("loc")} placeholder="Enter location" />
          <Input label="Patient (optional)" value={form.patient} onChange={f("patient")} />
          <div style={{display:"flex",gap:8,marginTop:8}}><Btn primary onClick={handleDispatch}>Dispatch Now</Btn><Btn onClick={()=>setShowDispatch(false)}>Cancel</Btn></div>
        </Modal>
      )}
    </div>
  );
}

function AdminPage({ state, setState, toast, addAudit, currentUser }) {
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ name:"", email:"", role:"Staff", dept:"General" });
  const f = k => v => setForm(p=>({...p,[k]:v}));
  const dotC = { success:"#22c55e", warning:"#f59e0b", danger:"#ef4444", info:"#1a63c8" };

  return (
    <div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:12,marginBottom:12}}>
        <StatCard label="Total Users" value={USERS.length} color="#1a63c8"/>
        <StatCard label="Active Sessions" value={1} color="#166534"/>
        <StatCard label="System Uptime" value="99.8%" color="#166534"/>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
        <Card>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10}}>
            <div style={{fontWeight:700,fontSize:13}}>System Users</div>
            {(!currentUser||currentUser.role!=='Patient')&&<Btn small primary onClick={()=>setShowAdd(true)}>+ Add User</Btn>}
          </div>
          <Table heads={["Name","Role","Department"]}
            rows={USERS.map(u=>[u.name,<Badge s={u.role}/>,u.dept])} />
        </Card>
        <Card>
          <div style={{fontWeight:700,fontSize:13,marginBottom:10}}>Audit Log</div>
          {state.auditLog.slice(0,8).map((a,i)=>(
            <div key={i} style={{display:"flex",gap:10,padding:"7px 0",borderBottom:i<7?"1px solid #f3f4f6":"none"}}>
              <div style={{width:8,height:8,borderRadius:"50%",background:dotC[a.color]||"#1a63c8",marginTop:4,flexShrink:0}}/>
              <div>
                <div style={{fontSize:12.5}}>{a.msg}</div>
                <div style={{fontSize:10.5,color:"#9ca3af"}}>{a.time}</div>
              </div>
            </div>
          ))}
        </Card>
      </div>
      {showAdd && (
        <Modal title="Add System User" onClose={()=>setShowAdd(false)}>
          <Input label="Full Name *" value={form.name} onChange={f("name")} />
          <Input label="Email *" value={form.email} onChange={f("email")} />
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
            <Sel label="Role" value={form.role} onChange={f("role")} options={["Admin","Doctor","Staff","Patient"]} />
            <Input label="Department" value={form.dept} onChange={f("dept")} />
          </div>
          <div style={{display:"flex",gap:8,marginTop:8}}><Btn primary onClick={()=>{toast(`✓ User ${form.name} created`);addAudit(`User ${form.name} created`,"success");setShowAdd(false);}}>Create User</Btn><Btn onClick={()=>setShowAdd(false)}>Cancel</Btn></div>
        </Modal>
      )}
    </div>
  );
}

function ReportsPage({ state }) {
  const patients    = state.patients    || [];
  const billing     = state.billing     || [];
  const doctors     = state.doctors     || [];
  const staff       = state.staff       || [];
  const pharmacy    = state.pharmacy    || [];
  const labReports  = state.labReports  || [];
  const surgeries   = state.surgeries   || [];
  const appointments= state.appointments|| [];
  const wards       = state.wards       || [];
  const bloodStock  = state.bloodStock  || {};
  const donors      = state.donors      || [];

  const [preview, setPreview] = useState(null);

  const totBilled = billing.reduce((s,b) => s + b.total, 0);
  const paidAmt   = billing.filter(b => b.status === 'Paid').reduce((s,b) => s + b.total, 0);
  const statGroups = {};
  patients.forEach(p => { statGroups[p.status] = (statGroups[p.status] || 0) + 1; });
  const deptCounts = {};
  patients.forEach(p => { deptCounts[p.dept] = (deptCounts[p.dept] || 0) + 1; });

  const CSS = '*{margin:0;padding:0;box-sizing:border-box}body{font-family:Segoe UI,Arial,sans-serif;font-size:13px;color:#1a1d24;background:#fff;padding:32px 40px}.hdr{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:2.5px solid #1a63c8;padding-bottom:14px;margin-bottom:20px}.brand{font-size:19px;font-weight:700;color:#1a63c8}.sub{font-size:11px;color:#6b7280;margin-top:3px}.meta{text-align:right;font-size:11px;color:#6b7280;line-height:1.8}h2{font-size:15px;font-weight:700;margin-bottom:14px;color:#1a1d24}.sec{font-size:10.5px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:#1a63c8;border-bottom:1px solid #dde2eb;padding-bottom:5px;margin:18px 0 10px}table{width:100%;border-collapse:collapse;font-size:12px;margin-bottom:14px}th{background:#1a63c8;color:#fff;text-align:left;padding:8px 10px;font-size:11px;font-weight:600}td{padding:7px 10px;border-bottom:1px solid #f0f2f7}tr:nth-child(even) td{background:#f8faff}.b{display:inline-block;padding:2px 8px;border-radius:20px;font-size:10px;font-weight:600}.bs{background:#dcfce7;color:#166534}.bw{background:#fef3c7;color:#92400e}.bd{background:#fee2e2;color:#9b1c1c}.bi{background:#dbeafe;color:#1a63c8}.kpi{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:16px}.kb{border:1px solid #dde2eb;border-radius:8px;padding:12px;border-left:3px solid #1a63c8}.kv{font-size:22px;font-weight:800;color:#1a63c8;margin:4px 0}.kl{font-size:10px;color:#6b7280;font-weight:600;text-transform:uppercase;letter-spacing:.05em}.ks{font-size:10.5px;color:#9ca3af;margin-top:2px}.ftr{margin-top:28px;padding-top:12px;border-top:1.5px solid #dde2eb;display:flex;justify-content:space-between;font-size:10px;color:#6b7280}.sig{width:160px;border-top:1px solid #1a1d24;margin-top:24px;padding-top:4px;text-align:center;font-size:10px;color:#6b7280}@media print{body{padding:20px}}';

  const genDate = new Date().toLocaleString('en-IN', { dateStyle:'long', timeStyle:'short' });

  const wrap = (title, body) =>
    '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><title>' + title + '</title><style>' + CSS + '</style></head><body>' +
    '<div class="hdr"><div><div class="brand">&#127973; MedCare Hospital, Bengaluru</div><div class="sub">123 Health Street, Koramangala</div><div class="sub">GST: 29AABCM1234A1Z5</div></div>' +
    '<div class="meta"><div style="font-weight:600;color:#1a1d24">' + title + '</div><div>Generated: ' + genDate + '</div></div></div>' +
    body +
    '<div class="ftr"><div>Computer-generated document &mdash; MedCare HMS &mdash; Confidential</div><div class="sig">Authorised Signatory</div></div></body></html>';

  const bstat = (s) => {
    const m = { Paid:'bs', Partial:'bw', Unpaid:'bd', Admitted:'bi', Discharged:'bs', OPD:'bi', Critical:'bd',
      Active:'bs', 'On Duty':'bs', 'On Leave':'bw', Ready:'bs', Processing:'bw', Pending:'bw',
      Scheduled:'bi', Completed:'bs', Available:'bs', Dispatched:'bi', Verified:'bs', Testing:'bw',
      'Low Stock':'bd', 'Out of Stock':'bd', Critical2:'bd' };
    return '<span class="b ' + (m[s] || 'bw') + '">' + s + '</span>';
  };

  const tbl = (heads, rows) => {
    const ths = heads.map(h => '<th>' + h + '</th>').join('');
    const trs = rows.map(r => '<tr>' + r.map(c => '<td>' + (c == null ? '&mdash;' : c) + '</td>').join('') + '</tr>').join('');
    return '<table><thead><tr>' + ths + '</tr></thead><tbody>' + trs + '</tbody></table>';
  };

  const kbox = (l, v, s) => '<div class="kb"><div class="kl">' + l + '</div><div class="kv">' + v + '</div><div class="ks">' + (s||'') + '</div></div>';
  const sec  = (t) => '<div class="sec">' + t + '</div>';
  const inr  = (n) => '&#8377;' + Number(n).toLocaleString('en-IN');
  const krow = (items) => '<div class="kpi">' + items.join('') + '</div>';

  const buildPatientSummary = () => {
    const ad = patients.filter(p => p.status === 'Admitted').length;
    const cr = patients.filter(p => p.status === 'Critical').length;
    const di = patients.filter(p => p.status === 'Discharged').length;
    const op = patients.filter(p => p.status === 'OPD').length;
    const pRows = patients.map(p => [p.id, p.fname+' '+p.lname, p.age, p.gender, p.dept, p.doctor, p.admitted, bstat(p.status)]);
    const dRows = Object.entries(deptCounts).sort((a,b)=>b[1]-a[1]).map(([d,c]) => [d, c, Math.round(c/Math.max(patients.length,1)*100)+'%']);
    return '<h2>Patient Summary Report</h2>' +
      krow([kbox('Total Patients',patients.length,ad+' admitted'),kbox('Critical',cr,'needs attention'),kbox('Discharged',di,'recovered'),kbox('OPD',op,'outpatient')]) +
      sec('Patient Registry') + tbl(['ID','Name','Age','Gender','Department','Doctor','Admitted','Status'],pRows) +
      sec('Department Distribution') + tbl(['Department','Count','% Share'],dRows);
  };

  const buildRevenue = () => {
    const part = billing.filter(b=>b.status==='Partial').reduce((s,b)=>s+b.total,0);
    const rows = billing.map(b => [b.inv, b.patient, b.services, inr(b.total), b.insurance?inr(b.insurance):'&mdash;', inr(Math.max(0,b.total-b.insurance)), b.mode, bstat(b.status)]);
    return '<h2>Revenue Report</h2>' +
      krow([kbox('Total Billed',inr(totBilled),billing.length+' invoices'),kbox('Received',inr(paidAmt),billing.filter(b=>b.status==='Paid').length+' paid'),kbox('Pending Dues',inr(totBilled-paidAmt),billing.filter(b=>b.status!=='Paid').length+' unpaid'),kbox('Partial',inr(part),billing.filter(b=>b.status==='Partial').length+' invoices')]) +
      sec('Invoice Details') + tbl(['Invoice','Patient','Services','Total','Insurance','Balance','Mode','Status'],rows);
  };

  const buildPharmacy = () => {
    const low = pharmacy.filter(m=>m.stock>0&&m.stock<m.reorder).length;
    const out = pharmacy.filter(m=>m.stock<=0).length;
    const ok  = pharmacy.filter(m=>m.stock>=m.reorder).length;
    const rows = pharmacy.map(m => [m.name, m.cat, m.mfg, '<strong>'+m.stock+'</strong>', m.reorder, m.expiry, inr(m.price), m.stock<=0?bstat('Out of Stock'):m.stock<m.reorder?bstat('Low Stock'):bstat('Ready')]);
    return '<h2>Pharmacy Report</h2>' +
      krow([kbox('Total Medicines',pharmacy.length,'in formulary'),kbox('Adequate',ok,'well stocked'),kbox('Low Stock',low,'needs reorder'),kbox('Out of Stock',out,'urgent')]) +
      sec('Medicine Inventory') + tbl(['Medicine','Category','Manufacturer','Stock','Reorder','Expiry','Price','Status'],rows);
  };

  const buildStaffAttendance = () => {
    const ac = staff.filter(s=>s.status==='Active').length;
    const lv = staff.filter(s=>s.status==='On Leave').length;
    const off= staff.filter(s=>s.status==='Off Duty').length;
    const rows = staff.map(s => [s.id, s.name, s.role, s.dept, s.shift, s.phone, bstat(s.status),
      s.status==='Active'?'<span style="color:#166534;font-weight:600">&#10003; Present</span>':'<span style="color:#9b1c1c;font-weight:600">&#10007; Absent</span>']);
    const d = new Date().toLocaleDateString('en-IN',{weekday:'long',day:'numeric',month:'long',year:'numeric'});
    return '<h2>Staff Attendance &mdash; ' + d + '</h2>' +
      krow([kbox('Total Staff',staff.length,'on roster'),kbox('Present',ac,'active today'),kbox('On Leave',lv,'absent'),kbox('Off Duty',off,'not scheduled')]) +
      sec('Attendance Register') + tbl(['ID','Name','Role','Dept','Shift','Phone','Status','Attendance'],rows);
  };

  const buildSurgery = () => {
    const co = surgeries.filter(s=>s.status==='Completed').length;
    const sc = surgeries.filter(s=>s.status==='Scheduled').length;
    const pe = surgeries.filter(s=>s.status==='Pending').length;
    const rows = surgeries.map(s => [s.id, s.patient, s.procedure, s.surgeon, s.ot, s.datetime, bstat(s.status)]);
    return '<h2>Surgery / OT Report</h2>' +
      krow([kbox('Total',surgeries.length,'all time'),kbox('Completed',co,'successful'),kbox('Scheduled',sc,'upcoming'),kbox('Pending',pe,'awaiting')]) +
      sec('Surgery Register') + tbl(['ID','Patient','Procedure','Surgeon','OT','Date &amp; Time','Status'],rows);
  };

  const buildLab = () => {
    const re = labReports.filter(l=>l.status==='Ready').length;
    const pr = labReports.filter(l=>l.status==='Processing').length;
    const pe = labReports.filter(l=>l.status==='Pending').length;
    const rows = labReports.map(l => [l.id, l.patient, l.test, l.orderedBy, l.date, bstat(l.status)]);
    return '<h2>Laboratory Report Summary</h2>' +
      krow([kbox('Total Tests',labReports.length,'ordered'),kbox('Ready',re,'results available'),kbox('Processing',pr,'in progress'),kbox('Pending',pe,'awaiting start')]) +
      sec('Lab Test Register') + tbl(['Report ID','Patient','Test','Ordered By','Date','Status'],rows);
  };

  const buildBloodBank = () => {
    const bgs  = ['A+','B+','O+','AB+','A-','B-','O-','AB-'];
    const bRows= bgs.map(bg => { const u=bloodStock[bg]||0; return [bg,'<strong>'+u+'</strong>',u<6?bstat('Critical'):u<12?bstat('Pending'):bstat('Ready')]; });
    const dRows= donors.map(d => [d.name,d.phone||'&mdash;',d.bg,d.units,d.date,bstat(d.status)]);
    return '<h2>Blood Bank Report</h2>' +
      sec('Blood Group Stock') + tbl(['Blood Group','Units Available','Status'],bRows) +
      sec('Donor Records ('+donors.length+' donors)') + tbl(['Donor','Phone','Group','Units','Date','Status'],dRows);
  };

  const buildFull = () => {
    const ad = patients.filter(p=>p.status==='Admitted').length;
    const od = doctors.filter(d=>d.status==='On Duty').length;
    const ac = staff.filter(s=>s.status==='Active').length;
    const aRows = appointments.map(a => [a.token,a.patient,a.doctor,a.date,a.time,a.type,bstat(a.status)]);
    const wRows = wards.map(w => [w.name,w.type,w.beds,w.occupied,w.beds-w.occupied,inr(w.rate)]);
    const bRows = billing.map(b => [b.inv,b.patient,b.services,inr(b.total),bstat(b.status)]);
    return '<h2>Full Hospital Summary Report</h2>' +
      krow([kbox('Patients',patients.length,ad+' admitted'),kbox('Doctors',doctors.length,od+' on duty'),kbox('Staff',staff.length,ac+' active'),kbox('Revenue',inr(totBilled),billing.length+' invoices')]) +
      sec('Appointments ('+appointments.length+')') + tbl(['Token','Patient','Doctor','Date','Time','Type','Status'],aRows) +
      sec('Ward Occupancy') + tbl(['Ward','Type','Total Beds','Occupied','Free','Rate/Day'],wRows) +
      sec('Billing Summary') + tbl(['Invoice','Patient','Services','Total','Status'],bRows);
  };

  const builders = {
    'Patient Summary':     buildPatientSummary,
    'Revenue Report':      buildRevenue,
    'Pharmacy Report':     buildPharmacy,
    'Staff Attendance':    buildStaffAttendance,
    'Surgery Report':      buildSurgery,
    'Lab Report Summary':  buildLab,
    'Blood Bank Report':   buildBloodBank,
    'Full Hospital Report':buildFull,
  };

  const getHTML = (name) => wrap(name, (builders[name] || (() => '<p>No data.</p>'))());

  const viewReport = (name) => setPreview({ title: name, html: getHTML(name) });

  const downloadReport = (name) => {
    // Open full report in a new window — user can Ctrl+P / Cmd+P to Save as PDF
    const html = getHTML(name);
    const win  = window.open('', '_blank');
    if (win) {
      win.document.write(html);
      win.document.close();
    } else {
      // If popup blocked, show inside modal
      setPreview({ title: name, html });
    }
  };

  const REPORT_TYPES = [
    { name:'Patient Summary',     icon:'🧑', desc:'All patients, status, departments' },
    { name:'Revenue Report',      icon:'💰', desc:'Billing, invoices, outstanding dues' },
    { name:'Pharmacy Report',     icon:'💊', desc:'Stock, low inventory, reorder alerts' },
    { name:'Staff Attendance',    icon:'👥', desc:'Staff roster, shifts, attendance register' },
    { name:'Surgery Report',      icon:'🔪', desc:'OT schedule, surgeries, outcomes' },
    { name:'Lab Report Summary',  icon:'🔬', desc:'All tests, pending and ready results' },
    { name:'Blood Bank Report',   icon:'🩸', desc:'Blood stock, donors, critical groups' },
    { name:'Full Hospital Report',icon:'🏥', desc:'Complete hospital summary, all modules' },
  ];

  return (
    <div>
      <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:12,marginBottom:14}}>
        <StatCard label='Total Patients' value={patients.length} color='#1a63c8' sub={patients.filter(p=>p.status==='Admitted'||p.status==='Critical').length+' admitted'}/>
        <StatCard label='Total Billed' value={rupee(totBilled)} color='#166534' sub={billing.length+' invoices'}/>
        <StatCard label='Received' value={rupee(paidAmt)} color='#1a63c8' sub={billing.filter(b=>b.status==='Paid').length+' paid'}/>
        <StatCard label='Pending Dues' value={rupee(totBilled-paidAmt)} color='#9b1c1c' sub={billing.filter(b=>b.status!=='Paid').length+' unpaid'}/>
      </div>
      <Card>
        <div style={{fontWeight:700,fontSize:13,marginBottom:14}}>Export Reports</div>
        <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:12}}>
          {REPORT_TYPES.map(r => (
            <div key={r.name} style={{border:'1px solid #e5e7eb',borderRadius:10,padding:14}}>
              <div style={{fontSize:22,marginBottom:6}}>{r.icon}</div>
              <div style={{fontSize:12.5,fontWeight:700,marginBottom:3,lineHeight:1.3}}>{r.name}</div>
              <div style={{fontSize:11,color:'#9ca3af',marginBottom:12,lineHeight:1.4}}>{r.desc}</div>
              <div style={{display:'flex',gap:6}}>
                <button onClick={() => viewReport(r.name)}
                  style={{flex:1,padding:'7px 0',borderRadius:6,border:'1px solid #dde2eb',background:'#fff',fontSize:11,fontWeight:600,cursor:'pointer',fontFamily:'inherit'}}>
                  👁 View
                </button>
                <button onClick={() => downloadReport(r.name)}
                  style={{flex:1,padding:'7px 0',borderRadius:6,border:'none',background:'#1a63c8',color:'#fff',fontSize:11,fontWeight:600,cursor:'pointer',fontFamily:'inherit'}}>
                  🖨 Print
                </button>
              </div>
            </div>
          ))}
        </div>
      </Card>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
        <Card>
          <div style={{fontWeight:700,fontSize:13,marginBottom:12}}>Patient Status Breakdown</div>
          {Object.entries(statGroups).map(([st,cnt]) => (
            <div key={st} style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:8}}>
              <Badge s={st}/><strong style={{fontSize:13}}>{cnt}</strong>
            </div>
          ))}
        </Card>
        <Card>
          <div style={{fontWeight:700,fontSize:13,marginBottom:12}}>Billing Breakdown</div>
          {[['Paid',billing.filter(b=>b.status==='Paid').length,'#166534'],
            ['Partial',billing.filter(b=>b.status==='Partial').length,'#92400e'],
            ['Unpaid',billing.filter(b=>b.status==='Unpaid').length,'#9b1c1c']
          ].map(([k,v,c]) => (
            <div key={k} style={{display:'flex',justifyContent:'space-between',padding:'6px 0',borderBottom:'1px solid #f3f4f6'}}>
              <span style={{color:'#6b7280',fontSize:13}}>{k}</span>
              <strong style={{color:c,fontSize:13}}>{v}</strong>
            </div>
          ))}
          <div style={{display:'flex',justifyContent:'space-between',padding:'10px 0 0',fontWeight:700}}>
            <span>Total Invoices</span><span>{billing.length}</span>
          </div>
        </Card>
      </div>
      {preview && (
        <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.5)',zIndex:9999,display:'flex',alignItems:'center',justifyContent:'center'}}
          onClick={() => setPreview(null)}>
          <div style={{background:'#fff',borderRadius:12,width:'92vw',maxWidth:980,height:'90vh',display:'flex',flexDirection:'column',boxShadow:'0 20px 60px rgba(0,0,0,0.3)'}}
            onClick={e => e.stopPropagation()}>
            <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'14px 20px',borderBottom:'1px solid #e5e7eb',flexShrink:0}}>
              <div style={{fontWeight:700,fontSize:14}}>{preview.title}</div>
              <div style={{display:'flex',gap:8}}>
                <button onClick={() => downloadReport(preview.title)}
                  style={{padding:'6px 16px',borderRadius:7,border:'none',background:'#1a63c8',color:'#fff',fontSize:12,fontWeight:600,cursor:'pointer',fontFamily:'inherit'}}>
                  🖨 Open & Print
                </button>
                <button onClick={() => setPreview(null)}
                  style={{padding:'6px 12px',borderRadius:7,border:'1px solid #e5e7eb',background:'#fff',fontSize:16,cursor:'pointer',fontWeight:700,color:'#6b7280',fontFamily:'inherit'}}>
                  ✕
                </button>
              </div>
            </div>
            <iframe srcDoc={preview.html} style={{flex:1,border:'none',borderRadius:'0 0 12px 12px'}} title={preview.title} sandbox="allow-same-origin" />
          </div>
        </div>
      )}
    </div>
  );
}

function NotificationsPage({ state, setState, toast }) {
  const markAll = () => { setState(s=>({...s,notifications:s.notifications.map(n=>({...n,read:true}))})); toast("✓ All marked as read"); };
  const markOne = i => setState(s=>({...s,notifications:s.notifications.map((n,idx)=>idx===i?{...n,read:true}:n)}));
  const clearAll = () => { setState(s=>({...s,notifications:[]})); toast("✓ Cleared"); };
  const unread = state.notifications.filter(n=>!n.read).length;
  const dotC = { success:"#22c55e", warning:"#f59e0b", danger:"#ef4444", info:"#1a63c8" };

  return (
    <div>
      <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:12}}>
        <div style={{fontSize:13,color:"#6b7280"}}>{unread} unread · {state.notifications.length} total</div>
        <div style={{display:"flex",gap:8}}>
          {unread>0&&<Btn primary small onClick={markAll}>Mark All Read</Btn>}
          {state.notifications.length>0&&<Btn small onClick={clearAll}>Clear All</Btn>}
        </div>
      </div>
      <Card>
        {state.notifications.length===0&&<div style={{textAlign:"center",color:"#9ca3af",padding:32,fontSize:13}}>No notifications</div>}
        {state.notifications.map((n,i)=>(
          <div key={i} style={{display:"flex",gap:12,padding:"12px 0",borderBottom:i<state.notifications.length-1?"1px solid #f3f4f6":"none",opacity:n.read?0.5:1}}>
            <div style={{width:8,height:8,borderRadius:"50%",background:dotC[n.color]||"#1a63c8",marginTop:6,flexShrink:0}}/>
            <div style={{flex:1}}>
              <div style={{fontSize:13,fontWeight:n.read?400:600}}>{n.msg}</div>
              <div style={{fontSize:11,color:"#9ca3af",marginTop:3}}>{n.time} · {n.src}</div>
            </div>
            {!n.read&&<button onClick={()=>markOne(i)} style={{background:"none",border:"1px solid #dde2eb",borderRadius:6,padding:"3px 10px",cursor:"pointer",fontSize:11,fontWeight:600}}>✓</button>}
          </div>
        ))}
      </Card>
    </div>
  );
}

// ─── LOGIN SCREEN ─────────────────────────────────────────────────────────────
function LoginScreen({ onLogin }) {
  const [mode, setMode]         = useState('login');
  const [activeRole, setActive] = useState('Admin');
  const [email, setEmail]       = useState('');
  const [pass,  setPass]        = useState('');
  const [showPass, setShowPass] = useState(false);
  const [err,   setErr]         = useState('');
  const [regUsers, setRegUsers] = useState([]);

  // Register — Patient only: Name, Email, Password (no phone, no extra fields)
  const [rName, setRName] = useState('');
  const [rEmail,setREmail]= useState('');
  const [rPass, setRPass] = useState('');
  const [showRP,setShowRP]= useState(false);
  const [rErr,  setRErr]  = useState('');
  const [regSuccess, setRegSuccess] = useState(false);

  const ROLES = [
    { role:'Admin',   icon:'👔' },
    { role:'Doctor',  icon:'🩺' },
    { role:'Patient', icon:'🧑' },
    { role:'Staff',   icon:'👩‍⚕️' },
  ];

  // Switching role always clears fields — never auto-fills
  const pickRole = r => { setActive(r); setEmail(''); setPass(''); setErr(''); if(r !== 'Patient') setMode('login'); };

  const handleLogin = () => {
    setErr('');
    const em = email.trim().toLowerCase();
    const pw = pass.trim();
    if(!em||!pw){ setErr('Please enter your email and password.'); return; }

    if(activeRole === 'Patient') {
      const staffEmails = Object.values(ROLE_CREDS).filter(Boolean).map(c=>c.email.toLowerCase());
      if(staffEmails.includes(em)){ setErr('This account is not a Patient account. Please select the correct role.'); return; }
      const regUser = regUsers.find(u=>u.email===em && u.pass===pw);
      if(!regUser){ setErr('Invalid email or password. Please register first.'); return; }
      onLogin(regUser);
      return;
    }

    // Admin / Doctor / Staff: only their own credentials work in their tab
    const allowed = ROLE_CREDS[activeRole];
    if(!allowed) return;
    if(em !== allowed.email.toLowerCase()){ setErr('This email is not valid for ' + activeRole + ' login.'); return; }
    if(pw !== allowed.pass){ setErr('Incorrect password for this account.'); return; }
    const user = USERS.find(u=>u.email.toLowerCase()===em);
    if(user) onLogin(user);
    else setErr('Login failed. Please try again.');
  };

  // Register — only Name, Email, Password (matches screenshot)
  const handleRegister = () => {
    setRErr('');
    if(!rName.trim()){ setRErr('Full name is required.'); return; }
    if(!rEmail.includes('@')){ setRErr('Enter a valid email address.'); return; }
    if(rPass.length<6){ setRErr('Password must be at least 6 characters.'); return; }
    const staffEmails = Object.values(ROLE_CREDS).filter(Boolean).map(c=>c.email.toLowerCase());
    if(staffEmails.includes(rEmail.toLowerCase())){ setRErr('This email is already registered.'); return; }
    if(regUsers.find(u=>u.email===rEmail.toLowerCase())){ setRErr('Email already registered. Please sign in.'); return; }
    const newUser = { email:rEmail.toLowerCase().trim(), pass:rPass, role:'Patient', name:rName.trim(), dept:'—' };
    setRegUsers(prev=>[...prev, newUser]);
    // Store for admin visibility — flag as new registration
    // Show success — do NOT auto-login, let patient sign in manually
    setRegSuccess(true);
    setTimeout(() => {
      setRegSuccess(false);
      setMode('login');
      setActive('Patient');
      setEmail(newUser.email);
      setPass('');
      setRName(''); setREmail(''); setRPass('');
    }, 2000);
  };

  // No hints or previews shown in any field

  const inp = (val,set,type,ph,extra) => (
    <input value={val} onChange={e=>{set(e.target.value);setErr('');setRErr('');}} type={type||'text'} placeholder={ph} autoComplete='off'
      onKeyDown={e=>e.key==='Enter'&&(mode==='login'?handleLogin():handleRegister())}
      style={{ width:'100%', padding:'9px 12px', border:'1px solid #dde2eb', borderRadius:8, fontSize:13, fontFamily:'inherit', boxSizing:'border-box', outline:'none', ...extra }} />
  );

  const label = txt => (
    <div style={{ fontSize:10, fontWeight:700, color:'#6b7280', textTransform:'uppercase', letterSpacing:'0.05em', marginBottom:4 }}>{txt}</div>
  );

  return (
    <div style={{ minHeight:'100vh', display:'flex', alignItems:'center', justifyContent:'center', background:'linear-gradient(140deg,#dbeafe 0%,#f0f4f9 55%,#dcfce7 100%)' }}>
      <div style={{ background:'#fff', border:'1px solid #e5e7eb', borderRadius:16, padding:'32px 36px', width:420, boxShadow:'0 8px 32px rgba(0,0,0,0.1)' }}>

        {/* Brand */}
        <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:24 }}>
          <div style={{ width:44, height:44, background:'#dbeafe', borderRadius:10, display:'flex', alignItems:'center', justifyContent:'center', fontSize:22 }}>🏥</div>
          <div>
            <div style={{ fontSize:18, fontWeight:800, color:'#1a1d24' }}>MedCare HMS</div>
            <div style={{ fontSize:11, color:'#6b7280', marginTop:1 }}>Hospital Management System</div>
          </div>
        </div>

        {/* Sign In / Register tabs — Register only shown for Patient */}
        <div style={{ display:'flex', background:'#f3f4f6', borderRadius:10, padding:3, marginBottom:20 }}>
          <button onClick={()=>{setMode('login');setErr('');setRErr('');}}
            style={{ flex:1, padding:'8px 0', borderRadius:8, border:'none', fontSize:13, fontWeight:600, cursor:'pointer', transition:'all 0.15s',
              background:mode==='login'?'#fff':'transparent', color:mode==='login'?'#1a1d24':'#6b7280',
              boxShadow:mode==='login'?'0 1px 4px rgba(0,0,0,0.1)':'none', fontFamily:'inherit' }}>
            Sign In
          </button>
          {activeRole === 'Patient' && (
            <button onClick={()=>{setMode('register');setErr('');setRErr('');}}
              style={{ flex:1, padding:'8px 0', borderRadius:8, border:'none', fontSize:13, fontWeight:600, cursor:'pointer', transition:'all 0.15s',
                background:mode==='register'?'#fff':'transparent', color:mode==='register'?'#1a1d24':'#6b7280',
                boxShadow:mode==='register'?'0 1px 4px rgba(0,0,0,0.1)':'none', fontFamily:'inherit' }}>
              Register
            </button>
          )}
        </div>

        {/* ── SIGN IN ── */}
        {mode === 'login' && (
          <>
            <div style={{ fontSize:10, fontWeight:700, color:'#6b7280', textTransform:'uppercase', letterSpacing:'0.05em', marginBottom:8 }}>Select Role</div>
            <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:8, marginBottom:20 }}>
              {ROLES.map(r=>(
                <button key={r.role} onClick={()=>pickRole(r.role)}
                  style={{ border:'1.5px solid '+(activeRole===r.role?'#1a63c8':'#e5e7eb'), borderRadius:10, padding:'10px 4px', textAlign:'center', cursor:'pointer',
                    background:activeRole===r.role?'#eff6ff':'#fff', color:activeRole===r.role?'#1a63c8':'#6b7280', fontSize:11.5, fontWeight:600, fontFamily:'inherit' }}>
                  <span style={{ fontSize:20, display:'block', marginBottom:4 }}>{r.icon}</span>{r.role}
                </button>
              ))}
            </div>

            <div style={{ marginBottom:12 }}>
              {label('Email')}
              {inp(email, v=>{setEmail(v);setErr('');}, 'text', '')}
            </div>

            <div style={{ marginBottom:16 }}>
              {label('Password')}
              <div style={{ position:'relative' }}>
                {inp(pass, v=>{setPass(v);setErr('');}, showPass?'text':'password', '', { paddingRight:40 })}
                <button onClick={()=>setShowPass(p=>!p)} tabIndex={-1}
                  style={{ position:'absolute', right:10, top:'50%', transform:'translateY(-50%)', background:'none', border:'none', cursor:'pointer', fontSize:14 }}>
                  {showPass?'🙈':'👁️'}
                </button>
              </div>
            </div>

            {err && <div style={{ color:'#9b1c1c', fontSize:12, background:'#fef2f2', borderRadius:8, padding:'8px 12px', marginBottom:12, display:'flex', alignItems:'center', gap:6 }}>⚠️ {err}</div>}

            <button onClick={handleLogin}
              style={{ width:'100%', padding:'11px 0', background:'#1a63c8', color:'#fff', border:'none', borderRadius:10, fontSize:14, fontWeight:700, cursor:'pointer', fontFamily:'inherit' }}>
              Sign In →
            </button>

            {activeRole === 'Patient' && (
              <div style={{ textAlign:'center', marginTop:12, fontSize:12, color:'#6b7280' }}>
                New patient?{' '}
                <button onClick={()=>setMode('register')} style={{ color:'#1a63c8', background:'none', border:'none', cursor:'pointer', fontWeight:600, textDecoration:'underline', fontSize:12, fontFamily:'inherit' }}>
                  Register here
                </button>
              </div>
            )}
          </>
        )}

        {/* ── REGISTER (Patient only — Name, Email, Password) ── */}
        {mode === 'register' && (
          <>
            <div style={{ marginBottom:14 }}>
              {label('Full Name')}
              <input value={rName} onChange={e=>{setRName(e.target.value);setRErr('');}} type='text' placeholder=''
                style={{ width:'100%', padding:'9px 12px', border:'1px solid #dde2eb', borderRadius:8, fontSize:13, fontFamily:'inherit', boxSizing:'border-box', outline:'none' }} />
            </div>

            <div style={{ marginBottom:14 }}>
              {label('Email')}
              <input value={rEmail} onChange={e=>{setREmail(e.target.value);setRErr('');}} type='email' placeholder=''
                style={{ width:'100%', padding:'9px 12px', border:'1px solid #dde2eb', borderRadius:8, fontSize:13, fontFamily:'inherit', boxSizing:'border-box', outline:'none' }} />
            </div>

            <div style={{ marginBottom:20 }}>
              {label('Password')}
              <div style={{ position:'relative' }}>
                <input value={rPass} onChange={e=>{setRPass(e.target.value);setRErr('');}} type={showRP?'text':'password'} placeholder=''
                  style={{ width:'100%', padding:'9px 40px 9px 12px', border:'1px solid #dde2eb', borderRadius:8, fontSize:13, fontFamily:'inherit', boxSizing:'border-box', outline:'none' }} />
                <button onClick={()=>setShowRP(p=>!p)} tabIndex={-1}
                  style={{ position:'absolute', right:10, top:'50%', transform:'translateY(-50%)', background:'none', border:'none', cursor:'pointer', fontSize:14 }}>
                  {showRP?'🙈':'👁️'}
                </button>
              </div>
            </div>

            {rErr && <div style={{ color:'#9b1c1c', fontSize:12, background:'#fef2f2', borderRadius:8, padding:'8px 12px', marginBottom:12, display:'flex', alignItems:'center', gap:6 }}>⚠️ {rErr}</div>}

            {regSuccess && (
              <div style={{ color:'#166534', fontSize:13, background:'#dcfce7', border:'1px solid #bbf7d0', borderRadius:8, padding:'12px 14px', marginBottom:12, textAlign:'center', fontWeight:600 }}>
                ✓ Account created! Redirecting to Sign In…
              </div>
            )}

            <button onClick={handleRegister}
              style={{ width:'100%', padding:'11px 0', background:'#1a63c8', color:'#fff', border:'none', borderRadius:10, fontSize:14, fontWeight:700, cursor:'pointer', fontFamily:'inherit' }}>
              Create Account →
            </button>

            <div style={{ textAlign:'center', marginTop:12, fontSize:12, color:'#6b7280' }}>
              Already have an account?{' '}
              <button onClick={()=>setMode('login')} style={{ color:'#1a63c8', background:'none', border:'none', cursor:'pointer', fontWeight:600, textDecoration:'underline', fontFamily:'inherit' }}>
                Sign In
              </button>
            </div>
          </>
        )}

      </div>
    </div>
  );
}


// ─── MAIN APP ─────────────────────────────────────────────────────────────────
const NAV = [
  { section:"Overview",        items:[{ label:"Dashboard",      icon:"📊", page:"dashboard"     }] },
  { section:"Patients & Care", items:[
    { label:"Patients",        icon:"🧑", page:"patients"      },
    { label:"Doctors",         icon:"🩺", page:"doctors"       },
    { label:"Appointments",    icon:"📅", page:"appointments"  },
    { label:"Medical Records", icon:"📋", page:"records"       },
    { label:"Lab Reports",     icon:"🔬", page:"lab"           },
  ]},
  { section:"Clinical",        items:[
    { label:"Pharmacy",        icon:"💊", page:"pharmacy"      },
    { label:"Surgery / OT",    icon:"🔪", page:"surgery"       },
    { label:"Rooms & Wards",   icon:"🛏", page:"rooms"         },
    { label:"Blood Bank",      icon:"🩸", page:"blood"         },
  ]},
  { section:"Operations",      items:[
    { label:"Staff",           icon:"👥", page:"staff"         },
    { label:"Billing",         icon:"💰", page:"billing"       },
    { label:"Inventory",       icon:"📦", page:"inventory"     },
    { label:"Ambulance",       icon:"🚑", page:"ambulance"     },
  ]},
  { section:"System",          items:[
    { label:"Admin Panel",     icon:"👔", page:"admin"         },
    { label:"Reports",         icon:"📈", page:"reports"       },
    { label:"Notifications",   icon:"🔔", page:"notifications" },
  ]},
];

const PAGE_TITLES = { dashboard:"Dashboard",patients:"Patients",doctors:"Doctors",appointments:"Appointments",records:"Medical Records",lab:"Lab Reports",pharmacy:"Pharmacy",surgery:"Surgery / OT",rooms:"Rooms & Wards",blood:"Blood Bank",staff:"Staff",billing:"Billing",inventory:"Inventory",ambulance:"Ambulance",admin:"Admin Panel",reports:"Reports & Analytics",notifications:"Notifications" };

export default function App() {
  const [user,  setUser]  = useState(null);
  const [page,  setPage]  = useState("dashboard");
  const [toast, setToast] = useState("");
  const [state, setState] = useState({
    patients:INIT_PATIENTS, doctors:INIT_DOCTORS, appointments:INIT_APPTS,
    records:INIT_RECORDS, labReports:INIT_LAB, pharmacy:INIT_PHARMA,
    surgeries:INIT_SURGERY, wards:INIT_WARDS, bloodStock:INIT_BLOOD,
    donors:INIT_DONORS, staff:INIT_STAFF, billing:INIT_BILLING,
    inventory:INIT_INVENTORY, ambulance:INIT_AMBULANCE,
    notifications:INIT_NOTIFICATIONS, auditLog:INIT_AUDIT,
  });
  const toastTimer = useRef(null);

  const showToast = msg => {
    setToast(msg);
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(""), 3000);
  };

  const addAudit = (msg, color="info") => {
    setState(s => ({...s, auditLog:[{msg,color,time:"Just now",ts:new Date().toISOString()},...s.auditLog].slice(0,50)}));
  };

  const addNotif = (msg, color, src) => {
    setState(s => ({...s, notifications:[{msg,color,src,time:"Just now",read:false},...s.notifications].slice(0,50)}));
  };

  if (!user) return <LoginScreen onLogin={u => { setUser(u); addAudit(`${u.name} logged in`, "success"); if(u.role==='Patient') setPage('appointments'); }} />;

  const unread = state.notifications.filter(n=>!n.read).length;
  const initials = user.name.split(" ").map(w=>w[0]).join("").slice(0,2).toUpperCase();
  const PATIENT_NAV = [
    { section:"Overview",        items:[{ label:"Dashboard",      icon:"📊", page:"dashboard"    }] },
    { section:"Patients & Care", items:[
      { label:"Patients",        icon:"🧑", page:"patients"     },
      { label:"Doctors",         icon:"🩺", page:"doctors"      },
      { label:"Appointments",    icon:"📅", page:"appointments" },
      { label:"Medical Records", icon:"📋", page:"records"      },
      { label:"Lab Reports",     icon:"🔬", page:"lab"          },
    ]},
    { section:"Clinical",        items:[
      { label:"Pharmacy",        icon:"💊", page:"pharmacy"     },
      { label:"Surgery / OT",    icon:"🔪", page:"surgery"      },
      { label:"Rooms & Wards",   icon:"🛏", page:"rooms"        },
      { label:"Blood Bank",      icon:"🩸", page:"blood"        },
    ]},
    { section:"Operations",      items:[
      { label:"Staff",           icon:"👥", page:"staff"        },
      { label:"Billing",         icon:"💰", page:"billing"      },
      { label:"Inventory",       icon:"📦", page:"inventory"    },
      { label:"Ambulance",       icon:"🚑", page:"ambulance"    },
    ]},
  ];

  const navSections = user.role === "Patient"
    ? PATIENT_NAV
    : user.role === "Doctor"
    ? NAV.map(sec => sec.section === "System" ? { ...sec, items: sec.items.filter(i => i.page !== "admin") } : sec)
    : user.role === "Staff"
    ? [
        { section:"Patients & Care", items:[
          { label:"Patients",        icon:"🧑", page:"patients"     },
          { label:"Doctors",         icon:"🩺", page:"doctors"      },
          { label:"Appointments",    icon:"📅", page:"appointments" },
          { label:"Medical Records", icon:"📋", page:"records"      },
          { label:"Lab Reports",     icon:"🔬", page:"lab"          },
        ]},
        { section:"Clinical",        items:[
          { label:"Pharmacy",        icon:"💊", page:"pharmacy"     },
          { label:"Surgery / OT",    icon:"🔪", page:"surgery"      },
          { label:"Rooms & Wards",   icon:"🛏", page:"rooms"        },
          { label:"Blood Bank",      icon:"🩸", page:"blood"        },
        ]},
        { section:"Operations",      items:[
          { label:"Staff",           icon:"👥", page:"staff"        },
          { label:"Billing",         icon:"💰", page:"billing"      },
          { label:"Inventory",       icon:"📦", page:"inventory"    },
          { label:"Ambulance",       icon:"🚑", page:"ambulance"    },
        ]},
        { section:"System",          items:[
          { label:"Reports",         icon:"📈", page:"reports"      },
          { label:"Notifications",   icon:"🔔", page:"notifications"},
        ]},
      ]
    : NAV;

  const sharedProps = { state, setState, toast:showToast, addAudit, addNotif, currentUser:user };

  const activePage = page;

  const pages = {
    dashboard:    <Dashboard    {...sharedProps} setPage={setPage} />,
    patients:     <PatientsPage {...sharedProps} />,
    doctors:      <DoctorsPage  {...sharedProps} />,
    appointments: <AppointmentsPage {...sharedProps} currentUser={user} />,
    records:      <RecordsPage  {...sharedProps} />,
    lab:          <LabPage      {...sharedProps} />,
    pharmacy:     <PharmacyPage {...sharedProps} />,
    surgery:      <SurgeryPage  {...sharedProps} />,
    rooms:        <WardsPage    {...sharedProps} />,
    blood:        <BloodBankPage {...sharedProps} />,
    staff:        <StaffPage    {...sharedProps} />,
    billing:      <BillingPage  {...sharedProps} />,
    inventory:    <InventoryPage {...sharedProps} />,
    ambulance:    <AmbulancePage {...sharedProps} />,
    admin:        <AdminPage    {...sharedProps} />,
    reports:      <ReportsPage  {...sharedProps} />,
    notifications:<NotificationsPage {...sharedProps} />,
  };

  return (
    <div style={{ display:"flex", height:"100vh", width:"100vw", overflow:"hidden", fontFamily:"'DM Sans',system-ui,sans-serif", fontSize:13.5, color:"#1a1d24", background:"#f0f4f9" }}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700;800&display=swap');
        @keyframes fadeIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}
        .animate-fade-in{animation:fadeIn 0.25s ease-out}
        *{box-sizing:border-box;margin:0;padding:0}
        ::-webkit-scrollbar{width:5px;height:5px}
        ::-webkit-scrollbar-thumb{background:#d1d5db;border-radius:10px}
        ::-webkit-scrollbar-track{background:transparent}`}
      </style>

      {/* Sidebar */}
      <div style={{ width:230, minWidth:230, height:"100vh", background:"#fff", borderRight:"1px solid #e5e7eb", display:"flex", flexDirection:"column", overflow:"hidden" }}>
        <div style={{ padding:"12px 16px 10px", borderBottom:"1px solid #e5e7eb", display:"flex", alignItems:"center", gap:10, flexShrink:0 }}>
          <div style={{ width:32, height:32, background:"#dbeafe", borderRadius:8, display:"flex", alignItems:"center", justifyContent:"center", fontSize:16, flexShrink:0 }}>🏥</div>
          <div>
            <div style={{ fontSize:14, fontWeight:700 }}>MedCare</div>
            <div style={{ fontSize:10, color:"#6b7280" }}>{user.role} Panel</div>
          </div>
        </div>
        <nav style={{ flex:1, overflowY:"auto", padding:"6px 0" }}>
          {navSections.map(sec => (
            <div key={sec.section}>
              <div style={{ fontSize:9.5, fontWeight:700, color:"#9ca3af", textTransform:"uppercase", letterSpacing:"0.08em", padding:"10px 16px 3px" }}>{sec.section}</div>
              {sec.items.map(item => (
                <div key={item.page} onClick={() => setPage(item.page)}
                  style={{ display:"flex", alignItems:"center", gap:9, padding:"7px 16px", cursor:"pointer", fontSize:13, color: activePage===item.page ? "#1a63c8" : "#6b7280",
                    borderLeft: `2.5px solid ${activePage===item.page?"#1a63c8":"transparent"}`,
                    background: activePage===item.page ? "#eff6ff" : "transparent", fontWeight: activePage===item.page ? 600 : 400, whiteSpace:"nowrap", userSelect:"none" }}>
                  <span style={{ fontSize:14, width:17, textAlign:"center", flexShrink:0 }}>{item.icon}</span>
                  {item.label}
                  {item.page==="notifications"&&unread>0&&<span style={{ marginLeft:"auto", background:"#ef4444", color:"#fff", borderRadius:"50%", minWidth:18, height:18, display:"flex", alignItems:"center", justifyContent:"center", fontSize:10, fontWeight:700 }}>{unread}</span>}
                </div>
              ))}
            </div>
          ))}
          <div onClick={() => { setUser(null); setPage('appointments'); }} style={{ display:"flex", alignItems:"center", gap:9, padding:"7px 16px", cursor:"pointer", fontSize:13, color:"#ef4444", borderLeft:"2.5px solid transparent", marginTop:8, userSelect:"none" }}>
            <span style={{ fontSize:14, width:17, textAlign:"center" }}>🚪</span> Logout
          </div>
        </nav>
        <div style={{ padding:"12px 16px", borderTop:"1px solid #e5e7eb", flexShrink:0, display:"flex", alignItems:"center", gap:9 }}>
          <div style={{ width:30, height:30, borderRadius:"50%", background:"#dbeafe", color:"#1a63c8", display:"flex", alignItems:"center", justifyContent:"center", fontSize:11, fontWeight:700, flexShrink:0 }}>{initials}</div>
          <div style={{ minWidth:0 }}>
            <div style={{ fontSize:12, fontWeight:600, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{user.name}</div>
            <div style={{ fontSize:10, color:"#9ca3af", overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{user.email}</div>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div style={{ flex:1, display:"flex", flexDirection:"column", minWidth:0, height:"100vh", overflow:"hidden" }}>
        {/* Topbar */}
        <div style={{ height:52, background:"#fff", borderBottom:"1px solid #e5e7eb", display:"flex", alignItems:"center", padding:"0 20px", gap:12, flexShrink:0 }}>
          <div style={{ fontSize:15, fontWeight:700, flex:1 }}>{PAGE_TITLES[activePage]||activePage}</div>
          <div style={{ display:"flex", alignItems:"center", gap:14 }}>
            <span style={{ fontSize:11.5, color:"#6b7280", fontFamily:"monospace" }}>{new Date().toLocaleDateString("en-IN",{day:"2-digit",month:"short",year:"numeric"})}</span>
            {user.role !== 'Patient' && <div style={{ position:"relative", cursor:"pointer" }} onClick={()=>setPage('notifications')}>
              🔔
              {unread>0&&<span style={{ position:"absolute", top:-2, right:-6, background:"#ef4444", color:"#fff", borderRadius:"50%", fontSize:9, minWidth:16, height:16, display:"flex", alignItems:"center", justifyContent:"center", fontWeight:700 }}>{unread}</span>}
            </div>}
            <span style={{ fontSize:11.5, background:"#dbeafe", color:"#1a63c8", padding:"3px 10px", borderRadius:20, fontWeight:600 }}>{user.role}</span>
            <button onClick={() => { setUser(null); setPage('dashboard'); }} style={{ padding:"5px 12px", borderRadius:8, border:"1px solid #e5e7eb", background:"#fff", fontSize:12, fontWeight:600, cursor:"pointer", fontFamily:"inherit" }}>Logout</button>
          </div>
        </div>

        {/* Page content */}
        <div style={{ flex:1, overflowY:"auto", padding:16 }}>
          {pages[activePage] || pages.appointments}
        </div>
      </div>

      {/* Toast */}
      {toast && (
        <div style={{ position:"fixed", bottom:24, left:"50%", transform:"translateX(-50%)", background:"#1a1d24", color:"#fff", padding:"10px 20px", borderRadius:10, fontSize:13, fontWeight:600, zIndex:99999, boxShadow:"0 4px 20px rgba(0,0,0,0.25)", animation:"fadeIn 0.2s" }}>
          {toast}
        </div>
      )}
    </div>
  );
}
